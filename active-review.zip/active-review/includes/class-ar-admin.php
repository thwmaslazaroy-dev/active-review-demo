<?php
/**
 * Admin UI: menu «Κριτικές Active».
 *
 * Κανόνες που ισχύουν σε ΚΑΘΕ σελίδα/ενέργεια εδώ:
 *  - capability manage_options (και στο μενού και ξανά μέσα σε κάθε handler),
 *  - nonce σε κάθε φόρμα που αλλάζει δεδομένα (check_admin_referer),
 *  - αλλαγές μόνο μέσω POST (admin-post.php), ποτέ με GET link,
 *  - μηνύματα μετά το redirect από λευκή λίστα κωδικών (όχι κείμενο από URL),
 *  - κάθε έξοδος με esc_html / esc_attr / esc_url.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Admin {

	const CAP      = 'manage_options';
	const SLUG     = 'active-review';
	const GROUP    = 'active_review_settings_group';
	const PER_PAGE = 30;

	/** @return void */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_active_review_tech_add', array( __CLASS__, 'handle_tech_add' ) );
		add_action( 'admin_post_active_review_tech_remove', array( __CLASS__, 'handle_tech_remove' ) );
		add_action( 'admin_post_active_review_delete', array( __CLASS__, 'handle_delete' ) );
		add_filter( 'plugin_action_links_' . AR_BASENAME, array( __CLASS__, 'action_links' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Menu & assets                                                       */
	/* ------------------------------------------------------------------ */

	/** @return void */
	public static function menu() {
		add_menu_page( __( 'Active Reviews', 'active-review' ), __( 'Active Reviews', 'active-review' ), self::CAP, self::SLUG, array( __CLASS__, 'page_stats' ), 'dashicons-star-filled', 58 );
		add_submenu_page( self::SLUG, __( 'Statistics', 'active-review' ), __( 'Statistics', 'active-review' ), self::CAP, self::SLUG, array( __CLASS__, 'page_stats' ) );
		add_submenu_page( self::SLUG, __( 'Negative comments', 'active-review' ), __( 'Negative comments', 'active-review' ), self::CAP, self::SLUG . '-comments', array( __CLASS__, 'page_comments' ) );
		add_submenu_page( self::SLUG, __( 'Technicians', 'active-review' ), __( 'Technicians', 'active-review' ), self::CAP, self::SLUG . '-technicians', array( __CLASS__, 'page_technicians' ) );
		add_submenu_page( self::SLUG, __( 'QR codes', 'active-review' ), __( 'QR codes', 'active-review' ), self::CAP, self::SLUG . '-qr', array( __CLASS__, 'page_qr' ) );
		add_submenu_page( self::SLUG, __( 'Settings', 'active-review' ), __( 'Settings', 'active-review' ), self::CAP, self::SLUG . '-settings', array( __CLASS__, 'page_settings' ) );
	}

	/**
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-settings' ) ) . '">' . esc_html__( 'Settings', 'active-review' ) . '</a>' );
		return $links;
	}

	/**
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_style( 'active-review-admin', AR_URL . 'assets/css/admin.css', array(), AR_VERSION );

		if ( false !== strpos( $hook, self::SLUG . '-settings' ) ) {
			wp_enqueue_media();
			wp_enqueue_script( 'active-review-admin', AR_URL . 'assets/js/admin.js', array(), AR_VERSION, true );
		}
		if ( false !== strpos( $hook, self::SLUG . '-qr' ) ) {
			wp_enqueue_script( 'active-review-qrlib', AR_URL . 'assets/lib/qrcode.js', array(), '1.4.4', true );
			wp_enqueue_script( 'active-review-qr', AR_URL . 'assets/js/admin-qr.js', array( 'active-review-qrlib' ), AR_VERSION, true );
		}
	}

	/* ------------------------------------------------------------------ */
	/* Shared helpers                                                      */
	/* ------------------------------------------------------------------ */

	/** Dies unless the current user is an administrator. */
	private static function require_cap() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'active-review' ), 403 );
		}
	}

	/**
	 * Redirects back to an admin page with a whitelisted notice code.
	 *
	 * @param string $page   Page slug.
	 * @param string $notice Notice code.
	 * @param array  $extra  Extra safe query args.
	 * @return void
	 */
	private static function back( $page, $notice, array $extra = array() ) {
		wp_safe_redirect( add_query_arg( array_merge( array( 'page' => $page, 'ar_notice' => $notice ), $extra ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Prints the notice for ?ar_notice=code, from a fixed list only. */
	private static function notice() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only, whitelisted.
		$code     = isset( $_GET['ar_notice'] ) ? sanitize_key( wp_unslash( $_GET['ar_notice'] ) ) : '';
		$messages = array(
			'tech_added'   => array( 'success', __( 'Technician saved.', 'active-review' ) ),
			'tech_removed' => array( 'success', __( 'Technician removed.', 'active-review' ) ),
			'tech_code'    => array( 'error', __( 'The code must be 2–32 characters: Latin letters, digits, hyphen or underscore.', 'active-review' ) ),
			'tech_name'    => array( 'error', __( 'The technician name is required.', 'active-review' ) ),
			'tech_max'     => array( 'error', __( 'Maximum number of technicians reached.', 'active-review' ) ),
			'deleted'      => array( 'success', __( 'The review was deleted.', 'active-review' ) ),
			'not_found'    => array( 'error', __( 'Not found.', 'active-review' ) ),
		);
		if ( isset( $messages[ $code ] ) ) {
			printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $messages[ $code ][0] ), esc_html( $messages[ $code ][1] ) );
		}
	}

	/**
	 * Date filter form (GET — read-only, no nonce needed).
	 *
	 * @param string $page  Page slug.
	 * @param array  $range Range.
	 * @return void
	 */
	private static function date_filter( $page, array $range ) {
		?>
		<form method="get" class="ar-filter">
			<input type="hidden" name="page" value="<?php echo esc_attr( $page ); ?>">
			<label><?php esc_html_e( 'From', 'active-review' ); ?> <input type="date" name="from" value="<?php echo esc_attr( $range['from'] ); ?>"></label>
			<label><?php esc_html_e( 'To', 'active-review' ); ?> <input type="date" name="to" value="<?php echo esc_attr( $range['to'] ); ?>"></label>
			<button type="submit" class="button"><?php esc_html_e( 'Filter', 'active-review' ); ?></button>
			<?php if ( $range['from'] || $range['to'] ) : ?>
				<a class="button-link" href="<?php echo esc_url( admin_url( 'admin.php?page=' . $page ) ); ?>"><?php esc_html_e( 'Clear', 'active-review' ); ?></a>
			<?php endif; ?>
		</form>
		<?php
	}

	/**
	 * @param string $code Technician code.
	 * @return string Display label (unescaped).
	 */
	private static function tech_label( $code ) {
		if ( '' === (string) $code ) {
			return __( 'General (no technician)', 'active-review' );
		}
		$name = AR_Technicians::name( $code );
		return '' !== $name ? $name . ' (' . $code . ')' : $code . ' — ' . __( 'removed', 'active-review' );
	}

	/**
	 * @param int $rating 1–5.
	 * @return string Escaped star string with accessible text.
	 */
	private static function stars( $rating ) {
		$rating = max( 0, min( 5, (int) $rating ) );
		return '<span class="ar-stars-txt" aria-hidden="true">' . str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating ) . '</span><span class="screen-reader-text">' . esc_html( $rating . '/5' ) . '</span>';
	}

	/* ------------------------------------------------------------------ */
	/* Page: statistics                                                    */
	/* ------------------------------------------------------------------ */

	/** @return void */
	public static function page_stats() {
		self::require_cap();
		$range = AR_Stats::range_from_request();
		$stats = AR_Repository::stats( $range['from_utc'], $range['to_utc'] );
		$total = max( 1, $stats['total'] );

		$export_url = wp_nonce_url(
			add_query_arg(
				array(
					'action' => AR_Export::ACTION,
					'from'   => $range['from'],
					'to'     => $range['to'],
				),
				admin_url( 'admin-post.php' )
			),
			AR_Export::ACTION
		);
		?>
		<div class="wrap ar-admin">
			<h1><?php esc_html_e( 'Active Reviews — Statistics', 'active-review' ); ?></h1>
			<?php self::date_filter( self::SLUG, $range ); ?>

			<div class="ar-cards">
				<div class="ar-cardbox"><span class="ar-cardbox__label"><?php esc_html_e( 'Total ratings', 'active-review' ); ?></span><strong><?php echo esc_html( number_format_i18n( $stats['total'] ) ); ?></strong></div>
				<div class="ar-cardbox"><span class="ar-cardbox__label"><?php esc_html_e( 'Average', 'active-review' ); ?></span><strong><?php echo null === $stats['avg'] ? '—' : esc_html( number_format_i18n( $stats['avg'], 2 ) ); ?></strong></div>
				<div class="ar-cardbox"><span class="ar-cardbox__label"><?php esc_html_e( 'Went to Google', 'active-review' ); ?></span><strong><?php echo esc_html( number_format_i18n( $stats['google'] ) ); ?></strong>
					<small><?php echo esc_html( $stats['total'] ? round( 100 * $stats['google'] / $total ) . '%' : '' ); ?></small></div>
			</div>

			<h2><?php esc_html_e( 'Star distribution', 'active-review' ); ?></h2>
			<table class="ar-dist" role="presentation">
				<?php foreach ( $stats['distribution'] as $stars => $n ) : ?>
					<?php $pct = $stats['total'] ? round( 100 * $n / $total ) : 0; ?>
					<tr>
						<th scope="row"><?php echo self::stars( $stars ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?></th>
						<td class="ar-dist__bar"><span style="width: <?php echo (int) $pct; ?>%"></span></td>
						<td><?php echo esc_html( number_format_i18n( $n ) . ' (' . $pct . '%)' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</table>

			<h2><?php esc_html_e( 'Per technician', 'active-review' ); ?></h2>
			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Technician', 'active-review' ); ?></th>
					<th><?php esc_html_e( 'Ratings', 'active-review' ); ?></th>
					<th><?php esc_html_e( 'Average', 'active-review' ); ?></th>
					<th><?php esc_html_e( '5 stars', 'active-review' ); ?></th>
					<th><?php esc_html_e( '1–4 stars', 'active-review' ); ?></th>
					<th><?php esc_html_e( 'Went to Google', 'active-review' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( empty( $stats['technicians'] ) ) : ?>
					<tr><td colspan="6"><?php esc_html_e( 'No ratings yet.', 'active-review' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $stats['technicians'] as $t ) : ?>
					<tr>
						<td><?php echo esc_html( self::tech_label( $t->technician_code ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) $t->total ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (float) $t->avg_rating, 2 ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) $t->fives ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) $t->lows ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) $t->google ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<p><a class="button button-primary" href="<?php echo esc_url( $export_url ); ?>"><?php esc_html_e( 'Export CSV', 'active-review' ); ?></a>
			<span class="description"><?php esc_html_e( 'Exports all ratings of the selected period.', 'active-review' ); ?></span></p>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* Page: negative comments                                             */
	/* ------------------------------------------------------------------ */

	/** @return void */
	public static function page_comments() {
		self::require_cap();
		$range = AR_Stats::range_from_request();
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$data  = AR_Repository::negatives( $range['from_utc'], $range['to_utc'], $paged, self::PER_PAGE );
		$pages = (int) ceil( $data['total'] / self::PER_PAGE );
		?>
		<div class="wrap ar-admin">
			<h1><?php esc_html_e( 'Negative comments (1–4 stars)', 'active-review' ); ?></h1>
			<?php self::notice(); ?>
			<?php self::date_filter( self::SLUG . '-comments', $range ); ?>
			<p><?php echo esc_html( sprintf( /* translators: %s: count */ __( '%s entries', 'active-review' ), number_format_i18n( $data['total'] ) ) ); ?></p>

			<table class="widefat striped ar-comments">
				<thead><tr>
					<th><?php esc_html_e( 'Date', 'active-review' ); ?></th>
					<th><?php esc_html_e( 'Rating', 'active-review' ); ?></th>
					<th><?php esc_html_e( 'Technician', 'active-review' ); ?></th>
					<th><?php esc_html_e( 'Comment', 'active-review' ); ?></th>
					<th><?php esc_html_e( 'Contact', 'active-review' ); ?></th>
					<th><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'active-review' ); ?></span></th>
				</tr></thead>
				<tbody>
				<?php if ( empty( $data['rows'] ) ) : ?>
					<tr><td colspan="6"><?php esc_html_e( 'No negative ratings in this period.', 'active-review' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $data['rows'] as $row ) : ?>
					<tr>
						<td><?php echo esc_html( AR_Stats::local( $row->created_at ) ); ?></td>
						<td><?php echo self::stars( $row->rating ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?></td>
						<td><?php echo esc_html( self::tech_label( $row->technician_code ) ); ?></td>
						<td class="ar-comment">
							<?php
							if ( (int) $row->anonymized ) {
								echo '<em>' . esc_html__( '(anonymized)', 'active-review' ) . '</em>';
							} elseif ( null === $row->comment || '' === $row->comment ) {
								echo '<em>' . esc_html__( '(no comment)', 'active-review' ) . '</em>';
							} else {
								echo nl2br( esc_html( $row->comment ) );
							}
							?>
						</td>
						<td>
							<?php echo '' !== $row->name ? esc_html( $row->name ) . '<br>' : ''; ?>
							<?php if ( '' !== $row->phone ) : ?>
								<a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $row->phone ) ); ?>"><?php echo esc_html( $row->phone ); ?></a>
							<?php endif; ?>
							<?php echo ( '' === $row->name && '' === $row->phone ) ? '—' : ''; ?>
						</td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm(<?php echo esc_attr( wp_json_encode( __( 'Delete this review permanently?', 'active-review' ) ) ); ?>);">
								<input type="hidden" name="action" value="active_review_delete">
								<input type="hidden" name="id" value="<?php echo (int) $row->id; ?>">
								<?php wp_nonce_field( 'active_review_delete_' . (int) $row->id ); ?>
								<button type="submit" class="button-link-delete"><?php esc_html_e( 'Delete', 'active-review' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $pages > 1 ) : ?>
				<div class="tablenav"><div class="tablenav-pages">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'    => add_query_arg( 'paged', '%#%' ),
								'format'  => '',
								'current' => $paged,
								'total'   => $pages,
							)
						)
					);
					?>
				</div></div>
			<?php endif; ?>
		</div>
		<?php
	}

	/** @return void */
	public static function handle_delete() {
		self::require_cap();
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		check_admin_referer( 'active_review_delete_' . $id );
		$ok = $id && AR_Repository::delete( $id );
		self::back( self::SLUG . '-comments', $ok ? 'deleted' : 'not_found' );
	}

	/* ------------------------------------------------------------------ */
	/* Page: technicians                                                   */
	/* ------------------------------------------------------------------ */

	/** @return void */
	public static function page_technicians() {
		self::require_cap();
		$techs = AR_Technicians::all();
		$base  = AR_Settings::review_page_url();
		?>
		<div class="wrap ar-admin">
			<h1><?php esc_html_e( 'Technicians', 'active-review' ); ?></h1>
			<?php self::notice(); ?>

			<h2><?php esc_html_e( 'Add technician', 'active-review' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ar-inline-form">
				<input type="hidden" name="action" value="active_review_tech_add">
				<?php wp_nonce_field( 'active_review_tech_add' ); ?>
				<label><?php esc_html_e( 'Name', 'active-review' ); ?> <input type="text" name="name" required maxlength="<?php echo (int) AR_Technicians::NAME_MAX; ?>"></label>
				<label><?php esc_html_e( 'Code', 'active-review' ); ?> <input type="text" name="code" required maxlength="32" pattern="[A-Za-z0-9_\-]{2,32}" placeholder="KOSTAS"></label>
				<button type="submit" class="button button-primary"><?php esc_html_e( 'Save', 'active-review' ); ?></button>
			</form>
			<p class="description"><?php esc_html_e( 'The code appears in the link (?t=CODE). Use Latin letters/digits, e.g. KOSTAS. Saving an existing code renames the technician.', 'active-review' ); ?></p>

			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Name', 'active-review' ); ?></th>
					<th><?php esc_html_e( 'Code', 'active-review' ); ?></th>
					<th><?php esc_html_e( 'Link', 'active-review' ); ?></th>
					<th><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'active-review' ); ?></span></th>
				</tr></thead>
				<tbody>
				<?php if ( empty( $techs ) ) : ?>
					<tr><td colspan="4"><?php esc_html_e( 'No technicians yet.', 'active-review' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $techs as $code => $name ) : ?>
					<?php $link = add_query_arg( 't', rawurlencode( $code ), $base ); ?>
					<tr>
						<td><?php echo esc_html( $name ); ?></td>
						<td><code><?php echo esc_html( $code ); ?></code></td>
						<td><a href="<?php echo esc_url( $link ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $link ); ?></a></td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm(<?php echo esc_attr( wp_json_encode( __( 'Remove this technician? Past ratings keep the code.', 'active-review' ) ) ); ?>);">
								<input type="hidden" name="action" value="active_review_tech_remove">
								<input type="hidden" name="code" value="<?php echo esc_attr( $code ); ?>">
								<?php wp_nonce_field( 'active_review_tech_remove_' . $code ); ?>
								<button type="submit" class="button-link-delete"><?php esc_html_e( 'Remove', 'active-review' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/** @return void */
	public static function handle_tech_add() {
		self::require_cap();
		check_admin_referer( 'active_review_tech_add' );
		$code   = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
		$name   = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$result = AR_Technicians::add( $code, $name );
		if ( is_wp_error( $result ) ) {
			$map = array(
				'ar_code' => 'tech_code',
				'ar_name' => 'tech_name',
				'ar_max'  => 'tech_max',
			);
			self::back( self::SLUG . '-technicians', $map[ $result->get_error_code() ] ?? 'tech_code' );
		}
		self::back( self::SLUG . '-technicians', 'tech_added' );
	}

	/** @return void */
	public static function handle_tech_remove() {
		self::require_cap();
		$code = isset( $_POST['code'] ) ? AR_Technicians::normalize_code( sanitize_text_field( wp_unslash( $_POST['code'] ) ) ) : '';
		check_admin_referer( 'active_review_tech_remove_' . $code );
		self::back( self::SLUG . '-technicians', AR_Technicians::remove( $code ) ? 'tech_removed' : 'not_found' );
	}

	/* ------------------------------------------------------------------ */
	/* Page: QR                                                            */
	/* ------------------------------------------------------------------ */

	/** @return void */
	public static function page_qr() {
		self::require_cap();
		$base  = AR_Settings::review_page_url();
		$items = array(
			array(
				'label' => __( 'General (no technician)', 'active-review' ),
				'file'  => 'general',
				'url'   => $base,
			),
		);
		foreach ( AR_Technicians::all() as $code => $name ) {
			$items[] = array(
				'label' => $name . ' (' . $code . ')',
				'file'  => strtolower( $code ),
				'url'   => add_query_arg( 't', rawurlencode( $code ), $base ),
			);
		}
		?>
		<div class="wrap ar-admin">
			<h1><?php esc_html_e( 'QR codes for printing', 'active-review' ); ?></h1>
			<?php if ( '' === (string) AR_Settings::get( 'review_page_url' ) ) : ?>
				<div class="notice notice-warning"><p>
					<?php echo esc_html( sprintf( /* translators: %s: URL */ __( 'The review page URL is not set in Settings; the default %s is used. Set it before printing.', 'active-review' ), $base ) ); ?>
				</p></div>
			<?php endif; ?>
			<p class="description"><?php esc_html_e( 'SVG is vector (ideal for print shops, any size). PNG is 2048×2048 px. Test-scan every code before printing.', 'active-review' ); ?></p>

			<div class="ar-qr-grid">
				<?php foreach ( $items as $item ) : ?>
					<figure class="ar-qr" data-ar-qr data-url="<?php echo esc_attr( $item['url'] ); ?>" data-file="<?php echo esc_attr( 'active-review-qr-' . sanitize_file_name( $item['file'] ) ); ?>">
						<div class="ar-qr__canvas" data-ar-qr-target aria-hidden="true"></div>
						<figcaption>
							<strong><?php echo esc_html( $item['label'] ); ?></strong><br>
							<code class="ar-qr__url"><?php echo esc_html( $item['url'] ); ?></code>
						</figcaption>
						<p>
							<button type="button" class="button" data-ar-qr-svg><?php esc_html_e( 'Download SVG', 'active-review' ); ?></button>
							<button type="button" class="button" data-ar-qr-png><?php esc_html_e( 'Download PNG', 'active-review' ); ?></button>
						</p>
					</figure>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* Page: settings                                                      */
	/* ------------------------------------------------------------------ */

	/** @return void */
	public static function register_settings() {
		register_setting(
			self::GROUP,
			AR_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'AR_Settings', 'sanitize' ),
				'show_in_rest'      => false,
				'default'           => AR_Settings::defaults(),
			)
		);
	}

	/**
	 * @param string $key   Option key.
	 * @param string $label Label.
	 * @param string $desc  Description.
	 * @param array  $attrs Extra attrs (type, placeholder...).
	 * @return void
	 */
	private static function field_text( $key, $label, $desc = '', array $attrs = array() ) {
		$id    = 'ar-' . $key;
		$type  = $attrs['type'] ?? 'text';
		$value = 'password' === $type ? '' : (string) AR_Settings::get( $key );
		?>
		<tr>
			<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></th>
			<td>
				<input class="regular-text" id="<?php echo esc_attr( $id ); ?>" type="<?php echo esc_attr( $type ); ?>"
					name="<?php echo esc_attr( AR_Settings::OPTION . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $value ); ?>"
					<?php echo isset( $attrs['placeholder'] ) ? 'placeholder="' . esc_attr( $attrs['placeholder'] ) . '"' : ''; ?>
					<?php echo 'password' === $type ? 'autocomplete="new-password"' : ''; ?>>
				<?php if ( '' !== $desc ) : ?><p class="description"><?php echo esc_html( $desc ); ?></p><?php endif; ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * @param string $key   Option key.
	 * @param string $label Label.
	 * @param string $desc  Description.
	 * @return void
	 */
	private static function field_check( $key, $label, $desc = '' ) {
		$id = 'ar-' . $key;
		?>
		<tr>
			<th scope="row"><?php echo esc_html( $label ); ?></th>
			<td>
				<label for="<?php echo esc_attr( $id ); ?>">
					<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( AR_Settings::OPTION . '[' . $key . ']' ); ?>" value="1" <?php checked( 1, (int) AR_Settings::get( $key ) ); ?>>
					<?php echo esc_html( $desc ); ?>
				</label>
			</td>
		</tr>
		<?php
	}

	/** @return void */
	public static function page_settings() {
		self::require_cap();
		$defaults  = AR_Settings::default_texts();
		$labels    = array(
			'text_title'         => __( 'Title above the stars', 'active-review' ),
			'text_high_thanks'   => __( 'Thank-you text (5 stars)', 'active-review' ),
			'text_google_button' => __( 'Google button label', 'active-review' ),
			'text_low_heading'   => __( 'Heading for 1–3 stars', 'active-review' ),
			'text_mid_heading'   => __( 'Heading for 4 stars', 'active-review' ),
			'text_low_thanks'    => __( 'Message after sending a comment', 'active-review' ),
			'text_gdpr'          => __( 'Privacy notice under the form', 'active-review' ),
		);
		$logo_id   = (int) AR_Settings::get( 'logo_id' );
		$has_token = '' !== (string) AR_Settings::get( 'telegram_token' );
		?>
		<div class="wrap ar-admin">
			<h1><?php esc_html_e( 'Active Reviews — Settings', 'active-review' ); ?></h1>
			<?php settings_errors(); // Σελίδα εκτός options-general: το WP δεν τα δείχνει μόνο του. ?>
			<form method="post" action="options.php">
				<?php settings_fields( self::GROUP ); ?>

				<h2><?php esc_html_e( 'Google', 'active-review' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php self::field_text( 'place_id', __( 'Google Place ID', 'active-review' ), __( 'Starts with ChIJ… See the README for how to find it.', 'active-review' ), array( 'placeholder' => 'ChIJ…' ) ); ?>
					<?php if ( AR_Settings::google_review_url() ) : ?>
						<tr><th scope="row"><?php esc_html_e( 'Test', 'active-review' ); ?></th>
							<td><a href="<?php echo esc_url( AR_Settings::google_review_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open the Google review form', 'active-review' ); ?></a></td></tr>
					<?php endif; ?>
					<?php self::field_check( 'show_google_link_on_low_rating', __( 'Google link on 1–3 stars', 'active-review' ), __( 'Also show a discreet Google review link after a 1–3 star rating (with 4 stars it is always shown).', 'active-review' ) ); ?>
				</table>

				<h2><?php esc_html_e( 'Page', 'active-review' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php self::field_text( 'review_page_url', __( 'Review page URL', 'active-review' ), __( 'The page that contains [active_review]. Used for the QR codes. Must be on this website.', 'active-review' ), array( 'type' => 'url', 'placeholder' => home_url( '/review/' ) ) ); ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'Logo', 'active-review' ); ?></th>
						<td>
							<input type="hidden" id="ar-logo_id" name="<?php echo esc_attr( AR_Settings::OPTION . '[logo_id]' ); ?>" value="<?php echo (int) $logo_id; ?>">
							<div id="ar-logo-preview" class="ar-logo-preview"><?php echo $logo_id ? wp_get_attachment_image( $logo_id, 'medium' ) : ''; ?></div>
							<button type="button" class="button" id="ar-logo-pick"><?php esc_html_e( 'Choose logo', 'active-review' ); ?></button>
							<button type="button" class="button-link-delete" id="ar-logo-clear" <?php echo $logo_id ? '' : 'hidden'; ?>><?php esc_html_e( 'Remove', 'active-review' ); ?></button>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Notifications', 'active-review' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php self::field_text( 'notify_email', __( 'Notification email', 'active-review' ), __( 'Receives every 1–4 star rating. Separate multiple addresses with commas. Empty = site admin email.', 'active-review' ), array( 'placeholder' => get_option( 'admin_email' ) ) ); ?>
					<?php self::field_text( 'max_emails_per_hour', __( 'Max notifications per hour', 'active-review' ), __( 'Protection against notification flooding. Ratings above the limit are still saved.', 'active-review' ), array( 'type' => 'number' ) ); ?>
					<?php self::field_text( 'telegram_token', __( 'Telegram bot token', 'active-review' ), $has_token ? __( 'A token is saved (hidden). Leave empty to keep it.', 'active-review' ) : __( 'Optional. Empty = Telegram disabled.', 'active-review' ), array( 'type' => 'password', 'placeholder' => $has_token ? '••••••••' : '' ) ); ?>
					<?php if ( $has_token ) : ?>
						<tr><th scope="row"></th><td><label><input type="checkbox" name="<?php echo esc_attr( AR_Settings::OPTION . '[telegram_token_clear]' ); ?>" value="1"> <?php esc_html_e( 'Delete the saved token', 'active-review' ); ?></label></td></tr>
					<?php endif; ?>
					<?php self::field_text( 'telegram_chat_id', __( 'Telegram chat ID', 'active-review' ), __( 'Numeric ID (groups start with -) or @channel.', 'active-review' ) ); ?>
				</table>

				<h2><?php esc_html_e( 'Texts', 'active-review' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Leave empty to use the default (translated automatically per language). Custom texts can be translated in WPML → String Translation (domain admin_texts_active_review_settings).', 'active-review' ); ?></p>
				<table class="form-table" role="presentation">
					<?php foreach ( AR_Settings::TEXT_FIELDS as $key => $max ) : ?>
						<tr>
							<th scope="row"><label for="ar-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $labels[ $key ] ); ?></label></th>
							<td><textarea class="large-text" rows="<?php echo $max > 300 ? 4 : 2; ?>" id="ar-<?php echo esc_attr( $key ); ?>" maxlength="<?php echo (int) $max; ?>"
								name="<?php echo esc_attr( AR_Settings::OPTION . '[' . $key . ']' ); ?>" placeholder="<?php echo esc_attr( $defaults[ $key ] ); ?>"><?php echo esc_textarea( (string) AR_Settings::get( $key ) ); ?></textarea></td>
						</tr>
					<?php endforeach; ?>
				</table>

				<h2><?php esc_html_e( 'Privacy & data', 'active-review' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php self::field_text( 'retention_months', __( 'Anonymize after (months)', 'active-review' ), __( 'Comments, names and phones older than this are erased automatically; ratings remain for statistics. 0 = never.', 'active-review' ), array( 'type' => 'number' ) ); ?>
					<?php self::field_check( 'delete_on_uninstall', __( 'Uninstall', 'active-review' ), __( 'Delete all data (table and settings) when the plugin is deleted.', 'active-review' ) ); ?>
				</table>

				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
