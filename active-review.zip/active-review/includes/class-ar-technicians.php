<?php
/**
 * Technicians registry: code => name, stored in one option.
 *
 * Ο κωδικός είναι το μόνο που ταξιδεύει στο URL (?t=KOSTAS), οπότε επιτρέπεται
 * μόνο αυστηρό αλφάβητο. Άγνωστος κωδικός από το URL αποθηκεύεται ως κενός,
 * ώστε κανείς να μην «γεμίσει» τα στατιστικά με κατασκευασμένους τεχνικούς.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Technicians {

	const OPTION   = 'active_review_technicians';
	const MAX      = 200;
	const NAME_MAX = 80;

	/**
	 * @return array<string,string> code => name, sorted by name.
	 */
	public static function all() {
		$list = get_option( self::OPTION, array() );
		if ( ! is_array( $list ) ) {
			return array();
		}
		$clean = array();
		foreach ( $list as $code => $name ) {
			$code = self::normalize_code( $code );
			if ( '' !== $code ) {
				$clean[ $code ] = (string) $name;
			}
		}
		asort( $clean, SORT_NATURAL | SORT_FLAG_CASE );
		return $clean;
	}

	/**
	 * Normalizes a code: uppercase, A-Z 0-9 _ -, 2–32 chars. Else ''.
	 *
	 * @param mixed $code Raw.
	 * @return string
	 */
	public static function normalize_code( $code ) {
		if ( ! is_scalar( $code ) ) {
			return '';
		}
		$code = strtoupper( trim( (string) $code ) );
		return preg_match( '/^[A-Z0-9_-]{2,32}$/', $code ) ? $code : '';
	}

	/**
	 * Resolves a code from the public URL to a known technician, or ''.
	 *
	 * @param mixed $code Raw.
	 * @return string
	 */
	public static function resolve( $code ) {
		$code = self::normalize_code( $code );
		if ( '' === $code ) {
			return '';
		}
		return array_key_exists( $code, self::all() ) ? $code : '';
	}

	/**
	 * @param string $code Code.
	 * @return string Name or ''.
	 */
	public static function name( $code ) {
		$all = self::all();
		return $all[ $code ] ?? '';
	}

	/**
	 * Adds/updates a technician.
	 *
	 * @param string $code Raw code.
	 * @param string $name Raw name.
	 * @return true|WP_Error
	 */
	public static function add( $code, $name ) {
		$code = self::normalize_code( $code );
		$name = mb_substr( sanitize_text_field( (string) $name ), 0, self::NAME_MAX );

		if ( '' === $code ) {
			return new WP_Error( 'ar_code', __( 'The code must be 2–32 characters: Latin letters, digits, hyphen or underscore.', 'active-review' ) );
		}
		if ( '' === $name ) {
			return new WP_Error( 'ar_name', __( 'The technician name is required.', 'active-review' ) );
		}

		$all = self::all();
		if ( ! isset( $all[ $code ] ) && count( $all ) >= self::MAX ) {
			return new WP_Error( 'ar_max', __( 'Maximum number of technicians reached.', 'active-review' ) );
		}
		$all[ $code ] = $name;
		update_option( self::OPTION, $all, false );
		return true;
	}

	/**
	 * Removes a technician. Οι παλιές βαθμολογίες κρατούν τον κωδικό τους.
	 *
	 * @param string $code Code.
	 * @return bool
	 */
	public static function remove( $code ) {
		$code = self::normalize_code( $code );
		$all  = self::all();
		if ( '' === $code || ! isset( $all[ $code ] ) ) {
			return false;
		}
		unset( $all[ $code ] );
		update_option( self::OPTION, $all, false );
		return true;
	}
}
