<?php
/**
 * Settings: one option array, strict sanitizers, translated defaults.
 *
 * Κάθε τιμή περνάει από sanitize() πριν σωθεί. Ό,τι δεν αναγνωρίζεται
 * απορρίπτεται — δεν σώζεται ποτέ «ό,τι ήρθε».
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Settings {

	const OPTION = 'active_review_settings';

	/** Editable texts: key => max length. Empty value = translated default. */
	const TEXT_FIELDS = array(
		'text_title'         => 150,
		'text_high_thanks'   => 300,
		'text_google_button' => 80,
		'text_low_heading'   => 200,
		'text_low_thanks'    => 300,
		'text_gdpr'          => 1000,
	);

	/** @var array|null Request-level cache. */
	private static $cache = null;

	/**
	 * Raw defaults (no translation here: called before init too).
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'place_id'                       => '',
			'notify_email'                   => '',
			'telegram_token'                 => '',
			'telegram_chat_id'               => '',
			'review_page_url'                => '',
			'logo_id'                        => 0,
			'text_title'                     => '',
			'text_high_thanks'               => '',
			'text_google_button'             => '',
			'text_low_heading'               => '',
			'text_low_thanks'                => '',
			'text_gdpr'                      => '',
			'show_google_link_on_low_rating' => 0,
			'retention_months'               => 12,
			'max_emails_per_hour'            => 30,
			'delete_on_uninstall'            => 0,
		);
	}

	/**
	 * All settings, merged over defaults.
	 *
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
		}
		return self::$cache;
	}

	/**
	 * One setting.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function get( $key ) {
		$all = self::all();
		return $all[ $key ] ?? null;
	}

	/** Clears the request cache (after save / in tests). */
	public static function flush() {
		self::$cache = null;
	}

	/**
	 * Translated default texts. Πηγή στα αγγλικά, ελληνικά μέσω .po/.l10n.php,
	 * ώστε να τα πιάνει και το WPML String Translation.
	 *
	 * @return array
	 */
	public static function default_texts() {
		return array(
			'text_title'         => __( 'How was your experience with Active?', 'active-review' ),
			'text_high_thanks'   => __( 'Thank you very much! It would help us a lot if you shared your experience on Google.', 'active-review' ),
			'text_google_button' => __( 'Write a review on Google', 'active-review' ),
			'text_low_heading'   => __( 'We are sorry! Tell us what we can improve.', 'active-review' ),
			'text_low_thanks'    => __( 'Thank you very much for your review, we will contact you if needed.', 'active-review' ),
			'text_gdpr'          => __( 'We store your rating, your comment and, only if you provide them, your name and phone number, so that we can improve our service and contact you if needed. We do not store your IP address: to prevent abuse we keep only an irreversible coded fingerprint of it for one hour, and a coded fingerprint of your browser type. Personal details are deleted automatically after a limited period. You can ask for deletion at any time by contacting Active Security.', 'active-review' ),
		);
	}

	/**
	 * A public text: admin value if set (translatable via WPML admin-texts),
	 * otherwise the translated default.
	 *
	 * @param string $key One of TEXT_FIELDS.
	 * @return string Plain text — escape on output.
	 */
	public static function text( $key ) {
		$value = (string) self::get( $key );
		if ( '' !== trim( $value ) ) {
			return $value;
		}
		$defaults = self::default_texts();
		return $defaults[ $key ] ?? '';
	}

	/**
	 * Google "write review" URL, or '' when no Place ID is configured.
	 *
	 * @return string
	 */
	public static function google_review_url() {
		$place_id = (string) self::get( 'place_id' );
		if ( '' === $place_id ) {
			return '';
		}
		return 'https://search.google.com/local/writereview?placeid=' . rawurlencode( $place_id );
	}

	/**
	 * Public review page URL (setting, else home).
	 *
	 * @return string
	 */
	public static function review_page_url() {
		$url = (string) self::get( 'review_page_url' );
		return '' !== $url ? $url : home_url( '/review/' );
	}

	/** @return bool */
	public static function telegram_enabled() {
		return '' !== (string) self::get( 'telegram_token' ) && '' !== (string) self::get( 'telegram_chat_id' );
	}

	/* ------------------------------------------------------------------ */
	/* Validators (public: reused by tests)                                */
	/* ------------------------------------------------------------------ */

	/**
	 * Google Place IDs are URL-safe base64-ish strings (e.g. ChIJ...).
	 *
	 * @param string $value Raw.
	 * @return string Valid ID or ''.
	 */
	public static function clean_place_id( $value ) {
		$value = trim( (string) $value );
		return preg_match( '/^[A-Za-z0-9_-]{10,255}$/', $value ) ? $value : '';
	}

	/**
	 * Comma-separated list of valid emails (max 5).
	 *
	 * @param string $value Raw.
	 * @return string
	 */
	public static function clean_emails( $value ) {
		$out = array();
		foreach ( explode( ',', (string) $value ) as $part ) {
			$email = sanitize_email( trim( $part ) );
			if ( '' !== $email && is_email( $email ) ) {
				$out[] = $email;
			}
		}
		return implode( ',', array_slice( array_unique( $out ), 0, 5 ) );
	}

	/**
	 * @param string $value Raw.
	 * @return string Valid bot token or ''.
	 */
	public static function clean_telegram_token( $value ) {
		$value = trim( (string) $value );
		return preg_match( '/^\d{5,15}:[A-Za-z0-9_-]{30,60}$/', $value ) ? $value : '';
	}

	/**
	 * Numeric chat id (groups are negative) or @channelname.
	 *
	 * @param string $value Raw.
	 * @return string
	 */
	public static function clean_telegram_chat_id( $value ) {
		$value = trim( (string) $value );
		return preg_match( '/^(-?\d{1,20}|@[A-Za-z][A-Za-z0-9_]{4,31})$/', $value ) ? $value : '';
	}

	/**
	 * Review page URL: http(s) AND same host as the site. Έτσι ένα QR δεν
	 * μπορεί ποτέ να τυπωθεί με σύνδεσμο προς ξένο domain (phishing).
	 *
	 * @param string $value Raw.
	 * @return string
	 */
	public static function clean_review_url( $value ) {
		$url = esc_url_raw( trim( (string) $value ), array( 'https', 'http' ) );
		if ( '' === $url ) {
			return '';
		}
		$host = wp_parse_url( $url, PHP_URL_HOST );
		$home = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! $host || ! $home || strtolower( $host ) !== strtolower( $home ) ) {
			return '';
		}
		// Η παράμετρος t προστίθεται από τη γεννήτρια QR — δεν κρατάμε query/fragment.
		return strtok( strtok( $url, '#' ), '?' );
	}

	/* ------------------------------------------------------------------ */
	/* Settings API sanitize callback                                       */
	/* ------------------------------------------------------------------ */

	/**
	 * Sanitizes the whole option array. Unknown keys are dropped.
	 *
	 * @param mixed $input Posted values.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$input   = is_array( $input ) ? wp_unslash( $input ) : array();
		$current = self::all();
		$out     = self::defaults();

		$out['place_id']     = self::clean_place_id( $input['place_id'] ?? '' );
		$out['notify_email'] = self::clean_emails( $input['notify_email'] ?? '' );

		// Telegram token = μυστικό. Το πεδίο δεν εμφανίζει ποτέ την τιμή·
		// κενό πεδίο σημαίνει «κράτα το υπάρχον», εκτός αν τσεκαριστεί η διαγραφή.
		$token_in = trim( (string) ( $input['telegram_token'] ?? '' ) );
		if ( ! empty( $input['telegram_token_clear'] ) ) {
			$out['telegram_token'] = '';
		} elseif ( '' === $token_in ) {
			$out['telegram_token'] = (string) $current['telegram_token'];
		} else {
			$out['telegram_token'] = self::clean_telegram_token( $token_in );
			if ( '' === $out['telegram_token'] ) {
				add_settings_error( self::OPTION, 'ar_token', __( 'The Telegram bot token is not valid and was not saved.', 'active-review' ) );
				$out['telegram_token'] = (string) $current['telegram_token'];
			}
		}
		$out['telegram_chat_id'] = self::clean_telegram_chat_id( $input['telegram_chat_id'] ?? '' );

		$raw_url                = (string) ( $input['review_page_url'] ?? '' );
		$out['review_page_url'] = self::clean_review_url( $raw_url );
		if ( '' !== trim( $raw_url ) && '' === $out['review_page_url'] ) {
			add_settings_error( self::OPTION, 'ar_url', __( 'The review page URL must belong to this website.', 'active-review' ) );
			$out['review_page_url'] = (string) $current['review_page_url']; // Κρατάμε την προηγούμενη έγκυρη τιμή.
		}

		$logo_id        = absint( $input['logo_id'] ?? 0 );
		$out['logo_id'] = ( $logo_id && wp_attachment_is_image( $logo_id ) ) ? $logo_id : 0;

		foreach ( self::TEXT_FIELDS as $key => $max ) {
			$value       = sanitize_textarea_field( (string) ( $input[ $key ] ?? '' ) );
			$out[ $key ] = mb_substr( $value, 0, $max );
		}

		$out['show_google_link_on_low_rating'] = empty( $input['show_google_link_on_low_rating'] ) ? 0 : 1;
		$out['delete_on_uninstall']            = empty( $input['delete_on_uninstall'] ) ? 0 : 1;
		$out['retention_months']               = min( 120, absint( $input['retention_months'] ?? 12 ) );
		$out['max_emails_per_hour']            = max( 1, min( 500, absint( $input['max_emails_per_hour'] ?? 30 ) ) );

		self::flush();
		return $out;
	}
}
