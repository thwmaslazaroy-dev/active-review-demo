<?php
/**
 * All database access. Every query with external values goes through
 * $wpdb->prepare() or $wpdb->insert/update (which prepare internally).
 *
 * Ημερομηνίες: αποθηκεύονται σε UTC. Η μετατροπή σε ώρα Ελλάδας γίνεται μόνο
 * στην εμφάνιση.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Repository {

	/** Πόση ώρα μετά τη βαθμολογία δέχεται ο browser σχόλιο/αλλαγή/κλικ Google. */
	const TOKEN_TTL = 7200;

	/* ------------------------------------------------------------------ */
	/* Tokens                                                              */
	/* ------------------------------------------------------------------ */

	/**
	 * New random token (shown once to the browser, only its hash is stored).
	 *
	 * @return string 48 hex chars.
	 */
	public static function new_token() {
		return bin2hex( random_bytes( 24 ) );
	}

	/**
	 * @param string $token Raw token.
	 * @return string sha256 hex, or '' when the token has the wrong shape.
	 */
	public static function hash_token( $token ) {
		if ( ! is_string( $token ) || ! preg_match( '/^[a-f0-9]{48}$/', $token ) ) {
			return '';
		}
		return hash( 'sha256', $token );
	}

	/* ------------------------------------------------------------------ */
	/* Writes                                                              */
	/* ------------------------------------------------------------------ */

	/**
	 * @param int    $rating     1–5 (already validated).
	 * @param string $technician Resolved code or ''.
	 * @param string $ua_hash    HMAC of the user agent.
	 * @param string $token_hash sha256 of the edit token.
	 * @return int Insert id, 0 on failure.
	 */
	public static function insert( $rating, $technician, $ua_hash, $token_hash ) {
		global $wpdb;
		$ok = $wpdb->insert(
			AR_Install::table(),
			array(
				'created_at'      => gmdate( 'Y-m-d H:i:s' ),
				'rating'          => (int) $rating,
				'technician_code' => (string) $technician,
				'ua_hash'         => (string) $ua_hash,
				'token_hash'      => (string) $token_hash,
			),
			array( '%s', '%d', '%s', '%s', '%s' )
		);
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Row by token, only while the token is fresh.
	 *
	 * @param string $token Raw token.
	 * @return object|null
	 */
	public static function find_by_token( $token ) {
		global $wpdb;
		$hash = self::hash_token( $token );
		if ( '' === $hash ) {
			return null;
		}
		$table = AR_Install::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - self::TOKEN_TTL );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is internal.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE token_hash = %s AND created_at >= %s LIMIT 1", $hash, $since ) );
		return $row ?: null;
	}

	/**
	 * Changes the rating while no feedback has been sent yet.
	 *
	 * @param int $id     Row id.
	 * @param int $rating 1–5.
	 * @return bool
	 */
	public static function update_rating( $id, $rating ) {
		global $wpdb;
		$table = AR_Install::table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$n = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET rating = %d WHERE id = %d AND feedback_at IS NULL", (int) $rating, (int) $id ) );
		return false !== $n;
	}

	/**
	 * Stores the feedback ONCE (feedback_at IS NULL guard = no overwrite).
	 *
	 * @param int    $id      Row id.
	 * @param string $comment Clean comment.
	 * @param string $name    Clean name.
	 * @param string $phone   Clean phone.
	 * @return bool True if this call wrote the feedback.
	 */
	public static function save_feedback( $id, $comment, $name, $phone ) {
		global $wpdb;
		$table = AR_Install::table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$n = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET comment = %s, name = %s, phone = %s, feedback_at = %s WHERE id = %d AND rating < 5 AND feedback_at IS NULL",
				$comment,
				$name,
				$phone,
				gmdate( 'Y-m-d H:i:s' ),
				(int) $id
			)
		);
		return 1 === $n;
	}

	/**
	 * @param int $id Row id.
	 * @return void
	 */
	public static function mark_google( $id ) {
		global $wpdb;
		$wpdb->update( AR_Install::table(), array( 'went_to_google' => 1 ), array( 'id' => (int) $id ), array( '%d' ), array( '%d' ) );
	}

	/**
	 * Atomically claims the right to notify: true only for the first caller.
	 * Έτσι το cron και το /feedback δεν στέλνουν ποτέ διπλό email.
	 *
	 * @param int $id Row id.
	 * @return bool
	 */
	public static function claim_notification( $id ) {
		global $wpdb;
		$table = AR_Install::table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$n = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET notified = 1 WHERE id = %d AND notified = 0 AND rating < 5", (int) $id ) );
		return 1 === $n;
	}

	/**
	 * @param int $id Row id.
	 * @return bool
	 */
	public static function delete( $id ) {
		global $wpdb;
		return (bool) $wpdb->delete( AR_Install::table(), array( 'id' => (int) $id ), array( '%d' ) );
	}

	/**
	 * GDPR storage limitation: wipes personal fields of old rows, keeps the
	 * anonymous rating for statistics.
	 *
	 * @param string $before UTC datetime.
	 * @return int Rows affected.
	 */
	public static function anonymize_before( $before ) {
		global $wpdb;
		$table = AR_Install::table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$n = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET comment = NULL, name = '', phone = '', ua_hash = '', token_hash = '', anonymized = 1 WHERE created_at < %s AND anonymized = 0", $before ) );
		return (int) $n;
	}

	/* ------------------------------------------------------------------ */
	/* Reads                                                               */
	/* ------------------------------------------------------------------ */

	/**
	 * @param int $id Row id.
	 * @return object|null
	 */
	public static function get( $id ) {
		global $wpdb;
		$table = AR_Install::table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ) );
		return $row ?: null;
	}

	/**
	 * Builds a prepared WHERE for a UTC date range (+ optional extra clause).
	 *
	 * @param string|null $from  UTC 'Y-m-d H:i:s' or null.
	 * @param string|null $to    UTC 'Y-m-d H:i:s' (exclusive) or null.
	 * @param string      $extra Static SQL (no user data!).
	 * @return string
	 */
	private static function where( $from, $to, $extra = '' ) {
		global $wpdb;
		$parts = array( '1=1' );
		if ( $from ) {
			$parts[] = $wpdb->prepare( 'created_at >= %s', $from );
		}
		if ( $to ) {
			$parts[] = $wpdb->prepare( 'created_at < %s', $to );
		}
		if ( '' !== $extra ) {
			$parts[] = $extra;
		}
		return implode( ' AND ', $parts );
	}

	/**
	 * Aggregate stats for a period.
	 *
	 * @param string|null $from UTC.
	 * @param string|null $to   UTC exclusive.
	 * @return array
	 */
	public static function stats( $from, $to ) {
		global $wpdb;
		$table = AR_Install::table();
		$where = self::where( $from, $to );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where is built with prepare().
		$totals = $wpdb->get_row( "SELECT COUNT(*) AS total, AVG(rating) AS avg_rating, SUM(went_to_google) AS google FROM {$table} WHERE {$where}" );
		$dist   = $wpdb->get_results( "SELECT rating, COUNT(*) AS n FROM {$table} WHERE {$where} GROUP BY rating", OBJECT_K );
		$techs  = $wpdb->get_results( "SELECT technician_code, COUNT(*) AS total, AVG(rating) AS avg_rating, SUM(rating = 5) AS fives, SUM(rating < 5) AS lows, SUM(went_to_google) AS google FROM {$table} WHERE {$where} GROUP BY technician_code ORDER BY total DESC" );
		// phpcs:enable

		$distribution = array();
		for ( $i = 5; $i >= 1; $i-- ) {
			$distribution[ $i ] = isset( $dist[ $i ] ) ? (int) $dist[ $i ]->n : 0;
		}

		return array(
			'total'        => (int) ( $totals->total ?? 0 ),
			'avg'          => null !== ( $totals->avg_rating ?? null ) ? round( (float) $totals->avg_rating, 2 ) : null,
			'google'       => (int) ( $totals->google ?? 0 ),
			'distribution' => $distribution,
			'technicians'  => is_array( $techs ) ? $techs : array(),
		);
	}

	/**
	 * Low ratings (1–4), newest first, paginated.
	 *
	 * @param string|null $from     UTC.
	 * @param string|null $to       UTC exclusive.
	 * @param int         $page     1-based.
	 * @param int         $per_page Rows.
	 * @return array{rows: array, total: int}
	 */
	public static function negatives( $from, $to, $page, $per_page ) {
		global $wpdb;
		$table  = AR_Install::table();
		$where  = self::where( $from, $to, 'rating < 5' );
		$offset = max( 0, ( (int) $page - 1 ) * (int) $per_page );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where}" );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, created_at, rating, technician_code, comment, name, phone, went_to_google, anonymized FROM {$table} WHERE {$where} ORDER BY created_at DESC, id DESC LIMIT %d OFFSET %d", (int) $per_page, $offset ) );
		// phpcs:enable

		return array(
			'rows'  => is_array( $rows ) ? $rows : array(),
			'total' => $total,
		);
	}

	/**
	 * Rows for CSV export, in batches (no huge memory spikes).
	 *
	 * @param string|null $from   UTC.
	 * @param string|null $to     UTC exclusive.
	 * @param int         $after  Last id of previous batch.
	 * @param int         $limit  Batch size.
	 * @return array
	 */
	public static function export_batch( $from, $to, $after, $limit ) {
		global $wpdb;
		$table = AR_Install::table();
		$where = self::where( $from, $to );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, created_at, rating, technician_code, comment, name, phone, went_to_google FROM {$table} WHERE {$where} AND id > %d ORDER BY id ASC LIMIT %d", (int) $after, (int) $limit ) );
		return is_array( $rows ) ? $rows : array();
	}
}
