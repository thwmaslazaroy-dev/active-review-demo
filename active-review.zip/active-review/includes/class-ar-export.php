<?php
/**
 * CSV export (admin only).
 *
 * Προστασία από CSV/formula injection: ένα σχόλιο όπως =HYPERLINK(...) θα
 * εκτελούνταν ως τύπος στο Excel. Κάθε κελί που ξεκινά με = + - @ TAB CR
 * παίρνει μπροστά απόστροφο.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Export {

	const ACTION = 'active_review_export';

	/** @return void */
	public static function init() {
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle' ) );
	}

	/**
	 * Neutralizes spreadsheet formulas.
	 *
	 * @param mixed $value Cell.
	 * @return string
	 */
	public static function cell( $value ) {
		$value = (string) $value;
		if ( '' !== $value && false !== strpos( "=+-@\t\r", $value[0] ) ) {
			$value = "'" . $value;
		}
		return $value;
	}

	/** @return void */
	public static function handle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'active-review' ), 403 );
		}
		check_admin_referer( self::ACTION );

		$range    = AR_Stats::range_from_request();
		$filename = 'active-reviews-' . wp_date( 'Y-m-d' ) . '.csv';

		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'X-Content-Type-Options: nosniff' );

		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // BOM: το Excel διαβάζει σωστά τα ελληνικά.
		fputcsv(
			$out,
			array(
				__( 'ID', 'active-review' ),
				__( 'Date', 'active-review' ),
				__( 'Rating', 'active-review' ),
				__( 'Technician code', 'active-review' ),
				__( 'Technician', 'active-review' ),
				__( 'Comment', 'active-review' ),
				__( 'Name', 'active-review' ),
				__( 'Phone', 'active-review' ),
				__( 'Went to Google', 'active-review' ),
			),
			',',
			'"',
			'\\'
		);

		$after = 0;
		do {
			$rows = AR_Repository::export_batch( $range['from_utc'], $range['to_utc'], $after, 500 );
			foreach ( $rows as $row ) {
				fputcsv(
					$out,
					array_map(
						array( __CLASS__, 'cell' ),
						array(
							$row->id,
							AR_Stats::local( $row->created_at ),
							$row->rating,
							$row->technician_code,
							AR_Technicians::name( $row->technician_code ),
							(string) $row->comment,
							$row->name,
							$row->phone,
							$row->went_to_google ? __( 'Yes', 'active-review' ) : __( 'No', 'active-review' ),
						)
					),
					',',
					'"',
					'\\'
				);
				$after = (int) $row->id;
			}
		} while ( count( $rows ) === 500 );

		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}
}
