<?php
/**
 * [active_review] — the public review widget.
 *
 * Το HTML είναι ΣΤΑΤΙΚΟ για όλους τους επισκέπτες (καμία προσωπική πληροφορία,
 * κανένα nonce), οπότε η σελίδα μπορεί με ασφάλεια να είναι cached. Ο κωδικός
 * τεχνικού (?t=) διαβάζεται από το JS και επικυρώνεται στον server.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Shortcode {

	const HANDLE = 'active-review';

	/** @var int Instance counter for unique ids. */
	private static $instance = 0;

	/** @return void */
	public static function init() {
		add_shortcode( 'active_review', array( __CLASS__, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_filter( 'script_loader_tag', array( __CLASS__, 'script_tag' ), 10, 2 );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
	}

	/**
	 * Registers assets; enqueues CSS in <head> when the current page has the
	 * shortcode (αποφεύγει «αναβόσβημα» χωρίς στυλ).
	 *
	 * @return void
	 */
	public static function register_assets() {
		wp_register_style( self::HANDLE, AR_URL . 'assets/css/review.css', array(), self::ver( 'assets/css/review.css' ) );
		wp_register_script(
			self::HANDLE,
			AR_URL . 'assets/js/review.js',
			array(),
			self::ver( 'assets/js/review.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		if ( self::page_has_shortcode() ) {
			wp_enqueue_style( self::HANDLE );
		}
	}

	/**
	 * Asset version = plugin version + mtime, ώστε μια ενημέρωση να μην
	 * σερβίρεται ποτέ με παλιό CSS/JS από browser ή CDN cache.
	 *
	 * @param string $rel Path relative to the plugin.
	 * @return string
	 */
	private static function ver( $rel ) {
		$mtime = @filemtime( AR_PATH . $rel ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return AR_VERSION . ( $mtime ? '.' . $mtime : '' );
	}

	/** @return bool */
	private static function page_has_shortcode() {
		if ( ! is_singular() ) {
			return false;
		}
		$post = get_post();
		return $post && has_shortcode( (string) $post->post_content, 'active_review' );
	}

	/**
	 * Marks our script so WP Rocket does not delay/combine it. Αν το «Delay
	 * JavaScript execution» την καθυστερούσε, το πρώτο πάτημα στα αστέρια θα
	 * χανόταν.
	 *
	 * @param string $tag    HTML.
	 * @param string $handle Handle.
	 * @return string
	 */
	public static function script_tag( $tag, $handle ) {
		if ( self::HANDLE !== $handle || false !== strpos( $tag, 'nowprocket' ) ) {
			return $tag;
		}
		return str_replace( '<script ', '<script nowprocket data-no-optimize="1" data-no-minify="1" ', $tag );
	}

	/**
	 * The review page should not appear in Google search results.
	 *
	 * @param array $robots Directives.
	 * @return array
	 */
	public static function robots( $robots ) {
		if ( self::page_has_shortcode() ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
		}
		return $robots;
	}

	/**
	 * Star SVG (decorative).
	 *
	 * @return string
	 */
	private static function star_svg() {
		return '<svg class="ar-star__icon" viewBox="0 0 24 24" width="48" height="48" aria-hidden="true" focusable="false"><path d="M12 2.6l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.5l-5.9 3.2 1.3-6.6-4.9-4.6 6.6-.8z"/></svg>';
	}

	/**
	 * Shortcode output.
	 *
	 * @return string
	 */
	public static function render() {
		wp_enqueue_style( self::HANDLE );
		wp_enqueue_script( self::HANDLE );

		++self::$instance;
		$uid = 'ar-' . self::$instance;

		$config = array(
			'restUrl' => esc_url_raw( rest_url( AR_Rest::NS . '/' ) ),
			'i18n'    => array(
				'network'   => __( 'Connection problem. Please check your internet and try again.', 'active-review' ),
				'generic'   => __( 'Something went wrong. Please try again.', 'active-review' ),
				'required'  => __( 'Please write a comment.', 'active-review' ),
				'sending'   => __( 'Sending…', 'active-review' ),
				'send'      => __( 'Send', 'active-review' ),
				/* translators: %s: number of characters left */
				'charsLeft' => __( '%s characters left', 'active-review' ),
				/* translators: %d: selected stars */
				'selected'  => __( 'You selected %d out of 5 stars.', 'active-review' ),
			),
		);

		$logo_id = (int) AR_Settings::get( 'logo_id' );
		$max     = AR_Rest::COMMENT_MAX;

		ob_start();
		?>
		<div class="ar-review" data-ar-root data-ar-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
			<div class="ar-card">
				<?php if ( $logo_id ) : ?>
					<div class="ar-logo">
						<?php
						echo wp_get_attachment_image(
							$logo_id,
							'medium',
							false,
							array(
								'class'         => 'ar-logo__img',
								'alt'           => esc_attr( get_bloginfo( 'name' ) ),
								'loading'       => 'eager',
								'fetchpriority' => 'high',
								'decoding'      => 'async',
							)
						);
						?>
					</div>
				<?php endif; ?>

				<section class="ar-step" data-ar-step="rate" aria-labelledby="<?php echo esc_attr( $uid ); ?>-title">
					<h2 class="ar-title" id="<?php echo esc_attr( $uid ); ?>-title"><?php echo esc_html( AR_Settings::text( 'text_title' ) ); ?></h2>
					<div class="ar-stars" role="group" aria-labelledby="<?php echo esc_attr( $uid ); ?>-title" data-ar-stars>
						<?php for ( $i = 1; $i <= 5; $i++ ) : ?>
							<button type="button" class="ar-star" data-value="<?php echo (int) $i; ?>" aria-pressed="false"
								aria-label="<?php echo esc_attr( sprintf( /* translators: %d: stars */ _n( '%d star out of 5', '%d stars out of 5', $i, 'active-review' ), $i ) ); ?>"
								tabindex="<?php echo 1 === $i ? '0' : '-1'; ?>">
								<?php echo self::star_svg(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup. ?>
							</button>
						<?php endfor; ?>
					</div>
					<p class="ar-hint"><?php esc_html_e( 'Tap a star to rate us.', 'active-review' ); ?></p>
				</section>

				<section class="ar-step" data-ar-step="high" hidden tabindex="-1" aria-labelledby="<?php echo esc_attr( $uid ); ?>-high">
					<h2 class="ar-title" id="<?php echo esc_attr( $uid ); ?>-high"><?php esc_html_e( 'Thank you!', 'active-review' ); ?></h2>
					<p class="ar-text"><?php echo esc_html( AR_Settings::text( 'text_high_thanks' ) ); ?></p>
					<a class="ar-btn ar-btn--google" href="#" data-ar-google hidden rel="noopener"><?php echo esc_html( AR_Settings::text( 'text_google_button' ) ); ?></a>
					<button type="button" class="ar-link" data-ar-change><?php esc_html_e( 'Change rating', 'active-review' ); ?></button>
				</section>

				<section class="ar-step" data-ar-step="low" hidden tabindex="-1" aria-labelledby="<?php echo esc_attr( $uid ); ?>-low">
					<h2 class="ar-title" id="<?php echo esc_attr( $uid ); ?>-low"><?php echo esc_html( AR_Settings::text( 'text_low_heading' ) ); ?></h2>
					<form class="ar-form" data-ar-form novalidate>
						<div class="ar-field">
							<label for="<?php echo esc_attr( $uid ); ?>-comment"><?php esc_html_e( 'Your comment', 'active-review' ); ?> <span class="ar-req" aria-hidden="true">*</span></label>
							<textarea id="<?php echo esc_attr( $uid ); ?>-comment" name="comment" rows="4" maxlength="<?php echo (int) $max; ?>" required aria-required="true" aria-describedby="<?php echo esc_attr( $uid ); ?>-count"></textarea>
							<span class="ar-count" id="<?php echo esc_attr( $uid ); ?>-count" data-ar-count data-max="<?php echo (int) $max; ?>"></span>
						</div>
						<div class="ar-field">
							<label for="<?php echo esc_attr( $uid ); ?>-name"><?php esc_html_e( 'Name (optional)', 'active-review' ); ?></label>
							<input id="<?php echo esc_attr( $uid ); ?>-name" name="name" type="text" maxlength="<?php echo (int) AR_Rest::NAME_MAX; ?>" autocomplete="name">
						</div>
						<div class="ar-field">
							<label for="<?php echo esc_attr( $uid ); ?>-phone"><?php esc_html_e( 'Phone (optional)', 'active-review' ); ?></label>
							<input id="<?php echo esc_attr( $uid ); ?>-phone" name="phone" type="tel" inputmode="tel" maxlength="<?php echo (int) AR_Rest::PHONE_MAX; ?>" autocomplete="tel">
						</div>
						<div class="ar-hp" aria-hidden="true">
							<label for="<?php echo esc_attr( $uid ); ?>-website">Website</label>
							<input id="<?php echo esc_attr( $uid ); ?>-website" name="website" type="text" tabindex="-1" autocomplete="off">
						</div>
						<p class="ar-error" role="alert" data-ar-error hidden></p>
						<button type="submit" class="ar-btn" data-ar-submit><?php esc_html_e( 'Send', 'active-review' ); ?></button>
					</form>
					<p class="ar-google-low" data-ar-google-low hidden>
						<a href="#" data-ar-google rel="noopener"><?php esc_html_e( 'Or write a review on Google', 'active-review' ); ?></a>
					</p>
					<button type="button" class="ar-link" data-ar-change><?php esc_html_e( 'Change rating', 'active-review' ); ?></button>
					<p class="ar-gdpr"><?php echo esc_html( AR_Settings::text( 'text_gdpr' ) ); ?></p>
				</section>

				<section class="ar-step" data-ar-step="done" hidden tabindex="-1" aria-labelledby="<?php echo esc_attr( $uid ); ?>-done">
					<svg class="ar-check" viewBox="0 0 24 24" width="56" height="56" aria-hidden="true" focusable="false"><path d="M9 16.2l-3.5-3.5L4 14.2l5 5 11-11-1.5-1.5z"/></svg>
					<h2 class="ar-title" id="<?php echo esc_attr( $uid ); ?>-done"><?php echo esc_html( AR_Settings::text( 'text_low_thanks' ) ); ?></h2>
				</section>

				<p class="ar-error" role="alert" data-ar-global-error hidden></p>
				<p class="ar-sr" aria-live="polite" data-ar-live></p>
				<noscript><p class="ar-text"><?php esc_html_e( 'Please enable JavaScript to leave a rating.', 'active-review' ); ?></p></noscript>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
