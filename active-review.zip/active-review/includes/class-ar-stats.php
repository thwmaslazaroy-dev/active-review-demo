<?php
/**
 * Date-range parsing for admin filters (site timezone → UTC).
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Stats {

	/**
	 * Validates a Y-m-d string strictly (real calendar date).
	 *
	 * @param mixed $value Raw.
	 * @return string '' when invalid.
	 */
	public static function clean_date( $value ) {
		if ( ! is_string( $value ) || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m ) ) {
			return '';
		}
		return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? $value : '';
	}

	/**
	 * Reads from/to from the query string.
	 *
	 * @return array{from: string, to: string, from_utc: ?string, to_utc: ?string}
	 */
	public static function range_from_request() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filter.
		$from = self::clean_date( isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '' );
		$to   = self::clean_date( isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '' );
		// phpcs:enable
		return self::range( $from, $to );
	}

	/**
	 * Local (site timezone) dates to UTC bounds. "to" is inclusive for the user.
	 *
	 * @param string $from Y-m-d or ''.
	 * @param string $to   Y-m-d or ''.
	 * @return array
	 */
	public static function range( $from, $to ) {
		$tz = wp_timezone();
		$utc = new DateTimeZone( 'UTC' );

		$from_utc = null;
		$to_utc   = null;
		if ( '' !== $from ) {
			$from_utc = ( new DateTimeImmutable( $from . ' 00:00:00', $tz ) )->setTimezone( $utc )->format( 'Y-m-d H:i:s' );
		}
		if ( '' !== $to ) {
			$to_utc = ( new DateTimeImmutable( $to . ' 00:00:00', $tz ) )->modify( '+1 day' )->setTimezone( $utc )->format( 'Y-m-d H:i:s' );
		}
		return array(
			'from'     => $from,
			'to'       => $to,
			'from_utc' => $from_utc,
			'to_utc'   => $to_utc,
		);
	}

	/**
	 * UTC DB datetime → local display string.
	 *
	 * @param string $utc DB value.
	 * @return string
	 */
	public static function local( $utc ) {
		$ts = strtotime( (string) $utc . ' UTC' );
		return $ts ? wp_date( 'd/m/Y H:i', $ts ) : '';
	}
}
