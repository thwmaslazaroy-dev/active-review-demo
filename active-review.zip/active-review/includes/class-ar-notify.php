<?php
/**
 * Notifications for low ratings (1–4): email (wp_mail → WP Mail SMTP) and
 * optional Telegram.
 *
 * Πότε στέλνεται:
 *  - αμέσως μόλις ο πελάτης στείλει σχόλιο, ή
 *  - μετά από DELAY δευτερόλεπτα μέσω WP-Cron, αν δεν έστειλε σχόλιο.
 * Το claim_notification() είναι ατομικό UPDATE, άρα ποτέ διπλό μήνυμα.
 *
 * Ασφάλεια περιεχομένου:
 *  - email ως text/plain → κανένα HTML/JS από χρήστη δεν «εκτελείται» στο inbox,
 *  - δεδομένα χρήστη ΜΟΝΟ στο σώμα, ποτέ σε headers/subject (header injection),
 *  - Telegram χωρίς parse_mode → κανένα markup injection,
 *  - ωριαίο όριο μηνυμάτων, ώστε μια επίθεση να μη γεμίσει το inbox ή να
 *    «κάψει» τη φήμη του SMTP.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Notify {

	const CRON_HOOK = 'active_review_notify';

	/** Seconds to wait for a comment before notifying without one. */
	const DELAY = 900;

	const TELEGRAM_API = 'https://api.telegram.org/bot';

	/** @return void */
	public static function init() {
		add_action( self::CRON_HOOK, array( __CLASS__, 'run' ) );
	}

	/**
	 * Schedules the fallback notification for a fresh low rating.
	 *
	 * @param int $id Row id.
	 * @return void
	 */
	public static function schedule( $id ) {
		$args = array( (int) $id );
		if ( ! wp_next_scheduled( self::CRON_HOOK, $args ) ) {
			wp_schedule_single_event( time() + self::DELAY, self::CRON_HOOK, $args );
		}
	}

	/**
	 * Sends the notification once (cron callback and direct call).
	 *
	 * @param int $id Row id.
	 * @return void
	 */
	public static function run( $id ) {
		$id = (int) $id;
		wp_clear_scheduled_hook( self::CRON_HOOK, array( $id ) );

		$row = AR_Repository::get( $id );
		if ( ! $row || (int) $row->rating >= 5 ) {
			return; // Άλλαξε σε 5 ή διαγράφηκε.
		}
		if ( ! AR_Repository::claim_notification( $id ) ) {
			return; // Ήδη ειδοποιήθηκε.
		}
		if ( ! AR_Guard::consume( 'ar_mail_cap', (int) AR_Settings::get( 'max_emails_per_hour' ) ) ) {
			return; // Όριο ωριαίων μηνυμάτων: η εγγραφή μένει στο admin.
		}

		$text = self::build_text( $row );
		self::send_email( $row, $text );
		if ( AR_Settings::telegram_enabled() ) {
			self::send_telegram( $text );
		}
	}

	/**
	 * Strips control characters (keeps newlines) — defence for plain text sinks.
	 *
	 * @param string $value Value.
	 * @return string
	 */
	public static function plain( $value ) {
		return (string) preg_replace( '/[\x00-\x09\x0B-\x1F\x7F]/u', '', (string) $value );
	}

	/**
	 * Plain-text message body.
	 *
	 * @param object $row DB row.
	 * @return string
	 */
	public static function build_text( $row ) {
		$tech  = (string) $row->technician_code;
		$tname = '' !== $tech ? AR_Technicians::name( $tech ) : '';
		$dash  = '—';

		$lines   = array();
		$lines[] = sprintf(
			/* translators: %d: star rating 1-4 */
			__( 'New low rating: %d/5', 'active-review' ),
			(int) $row->rating
		);
		$lines[] = '';
		$lines[] = __( 'Date:', 'active-review' ) . ' ' . wp_date( 'd/m/Y H:i', strtotime( $row->created_at . ' UTC' ) );
		$lines[] = __( 'Technician:', 'active-review' ) . ' ' . ( '' !== $tech ? trim( $tname . ' (' . $tech . ')' ) : $dash );
		$lines[] = __( 'Name:', 'active-review' ) . ' ' . ( '' !== $row->name ? self::plain( $row->name ) : $dash );
		$lines[] = __( 'Phone:', 'active-review' ) . ' ' . ( '' !== $row->phone ? self::plain( $row->phone ) : $dash );
		$lines[] = '';
		$lines[] = __( 'Comment:', 'active-review' );
		$lines[] = ( null !== $row->comment && '' !== $row->comment ) ? self::plain( $row->comment ) : __( '(the customer did not leave a comment)', 'active-review' );
		$lines[] = '';
		$lines[] = admin_url( 'admin.php?page=active-review-comments' );

		return implode( "\n", $lines );
	}

	/**
	 * @param object $row  DB row.
	 * @param string $text Body.
	 * @return bool
	 */
	public static function send_email( $row, $text ) {
		$to = (string) AR_Settings::get( 'notify_email' );
		if ( '' === $to ) {
			$to = (string) get_option( 'admin_email' );
		}
		if ( '' === $to ) {
			return false;
		}
		// Subject: μόνο ακέραιος και σταθερό κείμενο — ποτέ δεδομένα χρήστη.
		$subject = sprintf(
			/* translators: %d: star rating */
			__( '[Active Review] Low rating %d/5', 'active-review' ),
			(int) $row->rating
		);
		return (bool) wp_mail( explode( ',', $to ), $subject, $text, array( 'Content-Type: text/plain; charset=UTF-8' ) );
	}

	/**
	 * @param string $text Body.
	 * @return bool
	 */
	public static function send_telegram( $text ) {
		$token = (string) AR_Settings::get( 'telegram_token' );
		$chat  = (string) AR_Settings::get( 'telegram_chat_id' );
		if ( '' === $token || '' === $chat ) {
			return false;
		}
		$response = wp_remote_post(
			self::TELEGRAM_API . $token . '/sendMessage',
			array(
				'timeout' => 10,
				'body'    => array(
					'chat_id'                  => $chat,
					'text'                     => mb_substr( $text, 0, 3500 ),
					'disable_web_page_preview' => 'true',
				),
			)
		);
		return ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response );
	}
}
