<?php
/**
 * GDPR storage limitation: daily job that anonymizes old rows.
 *
 * Μετά από N μήνες (ρύθμιση, προεπιλογή 12) σβήνονται σχόλιο, όνομα,
 * τηλέφωνο και hashes· μένει μόνο η ανώνυμη βαθμολογία για τα στατιστικά.
 * 0 μήνες = απενεργοποιημένο.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Retention {

	const CRON_HOOK = 'active_review_retention';

	/** @return void */
	public static function init() {
		add_action( self::CRON_HOOK, array( __CLASS__, 'run' ) );
		// Αυτο-επισκευή αν το event χάθηκε (π.χ. migration βάσης).
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			self::schedule();
		}
	}

	/** @return void */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	/** @return int Rows anonymized. */
	public static function run() {
		$months = (int) AR_Settings::get( 'retention_months' );
		if ( $months <= 0 ) {
			return 0;
		}
		$before = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $months . ' months' ) );
		return AR_Repository::anonymize_before( $before );
	}
}
