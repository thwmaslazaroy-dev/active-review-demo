<?php
/**
 * Abuse protection for the public endpoints.
 *
 * Η σελίδα κριτικής είναι cached (WP Rocket), οπότε δεν μπορούμε να βασιστούμε
 * σε nonce. Αντί γι' αυτό, κάθε δημόσιο αίτημα περνάει από στρώσεις:
 *   1. μέγεθος σώματος και Content-Type JSON,
 *   2. έλεγχο Origin/Referer (μόνο από το δικό μας domain),
 *   3. honeypot και ελάχιστο χρόνο ανθρώπινης αντίδρασης,
 *   4. rate limit ανά IP-hash και συνολικό όριο για όλο το site,
 *   5. αυστηρό validation κάθε πεδίου (στο AR_Rest).
 *
 * Η IP δεν αποθηκεύεται ΠΟΤΕ. Κρατάμε μόνο HMAC-SHA256 με μυστικό του site
 * (wp_salt), σε transient που λήγει σε 1 ώρα. Το hash δεν αντιστρέφεται χωρίς
 * το salt, και ακόμα και με αυτό θα χρειαζόταν brute force σε όλο τον χώρο IP.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Guard {

	/** Max raw body size of any public request. */
	const MAX_BODY = 8192;

	/** Faster than this from page load to action = bot. */
	const MIN_HUMAN_MS = 400; // Χαμηλά: ψεύτικο «bot» = χαμένη πραγματική κριτική. Τα JS bots δρουν σε <100ms.

	/** Per-IP limits per hour, per bucket. */
	const LIMITS = array(
		'rate'     => 5,   // Νέες βαθμολογίες.
		'change'   => 20,  // Αλλαγή αστεριών με υπάρχον token.
		'feedback' => 5,
		'google'   => 20,
	);

	/** Site-wide ceiling of NEW ratings per hour (κατανεμημένη επίθεση / email flood). */
	const GLOBAL_LIMIT = 300;

	const WINDOW = HOUR_IN_SECONDS;

	/* ------------------------------------------------------------------ */
	/* Identity (hashed)                                                   */
	/* ------------------------------------------------------------------ */

	/**
	 * Client IP. Προτεραιότητα στο Wordfence (σέβεται τη ρύθμιση «How does
	 * Wordfence get IPs» για proxy/Cloudflare), αλλιώς REMOTE_ADDR.
	 * Ποτέ X-Forwarded-For απευθείας: πλαστογραφείται τετριμμένα.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$ip = '';
		if ( class_exists( 'wfUtils' ) && is_callable( array( 'wfUtils', 'getIP' ) ) ) {
			$ip = (string) wfUtils::getIP();
		}
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated below.
		}
		/**
		 * Filters the client IP used for rate limiting (never stored).
		 *
		 * @param string $ip
		 */
		$ip = (string) apply_filters( 'active_review_client_ip', $ip );
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	}

	/**
	 * Keyed hash. IPv6 is bucketed by /64 so an attacker cannot rotate
	 * addresses inside one allocation to escape the limit.
	 *
	 * @param string $ip IP.
	 * @return string 64 hex chars.
	 */
	public static function ip_hash( $ip ) {
		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
			$bin = inet_pton( $ip );
			$ip  = bin2hex( substr( $bin, 0, 8 ) ) . '::/64';
		}
		return hash_hmac( 'sha256', 'ip|' . $ip, wp_salt( 'nonce' ) );
	}

	/**
	 * @return string 64 hex chars ('' if no UA).
	 */
	public static function ua_hash() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 512 ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only hashed.
		return '' === $ua ? '' : hash_hmac( 'sha256', 'ua|' . $ua, wp_salt( 'nonce' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Request checks                                                      */
	/* ------------------------------------------------------------------ */

	/**
	 * Transport-level checks. Returns WP_Error to reject, true to continue.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return true|WP_Error
	 */
	public static function check_transport( WP_REST_Request $request ) {
		if ( strlen( (string) $request->get_body() ) > self::MAX_BODY ) {
			return new WP_Error( 'ar_too_large', __( 'Request too large.', 'active-review' ), array( 'status' => 413 ) );
		}

		$type = (string) $request->get_header( 'content_type' );
		if ( 0 !== stripos( $type, 'application/json' ) ) {
			return new WP_Error( 'ar_bad_type', __( 'Invalid request.', 'active-review' ), array( 'status' => 415 ) );
		}

		if ( ! self::same_origin( (string) $request->get_header( 'origin' ), (string) $request->get_header( 'referer' ) ) ) {
			return new WP_Error( 'ar_origin', __( 'Invalid request.', 'active-review' ), array( 'status' => 403 ) );
		}

		return true;
	}

	/**
	 * Accepts if Origin (or, without it, Referer) belongs to this site.
	 * Αν λείπουν και τα δύο (σπάνιοι privacy browsers) επιτρέπουμε — τα
	 * υπόλοιπα στρώματα (rate limit) καλύπτουν· η απόρριψη θα έκοβε πελάτες.
	 *
	 * @param string $origin  Origin header.
	 * @param string $referer Referer header.
	 * @return bool
	 */
	public static function same_origin( $origin, $referer ) {
		$home = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$src  = '' !== $origin ? $origin : $referer;
		if ( '' === $src ) {
			return true;
		}
		if ( 'null' === strtolower( $src ) ) {
			return false;
		}
		$host = strtolower( (string) wp_parse_url( $src, PHP_URL_HOST ) );
		// www.activesec.gr και activesec.gr θεωρούνται ίδιο site.
		$strip = static function ( $h ) {
			return preg_replace( '/^www\./', '', $h );
		};
		return '' !== $host && $strip( $host ) === $strip( $home );
	}

	/**
	 * Honeypot + timing. Returns true when the request looks automated.
	 * Ο caller απαντά «επιτυχία» χωρίς να αποθηκεύσει τίποτα, ώστε το bot
	 * να μη μάθει ότι εντοπίστηκε.
	 *
	 * @param array $params JSON params.
	 * @return bool
	 */
	public static function is_bot( array $params ) {
		$hp = $params['website'] ?? '';
		if ( ! is_string( $hp ) || '' !== $hp ) {
			return true;
		}
		$elapsed = $params['elapsed'] ?? null;
		if ( ! is_int( $elapsed ) || $elapsed < self::MIN_HUMAN_MS ) {
			return true;
		}
		return false;
	}

	/* ------------------------------------------------------------------ */
	/* Rate limiting (fixed window, transients)                            */
	/* ------------------------------------------------------------------ */

	/**
	 * Consumes one unit of a bucket. False = limit reached (nothing consumed).
	 *
	 * @param string $bucket Key of LIMITS.
	 * @param string $ip_hash Hash.
	 * @return bool
	 */
	public static function hit( $bucket, $ip_hash ) {
		$limit = (int) ( self::LIMITS[ $bucket ] ?? 5 );
		/**
		 * Filters a per-IP hourly limit.
		 *
		 * @param int    $limit
		 * @param string $bucket
		 */
		$limit = (int) apply_filters( 'active_review_rate_limit', $limit, $bucket );
		return self::consume( 'ar_rl_' . $bucket . '_' . substr( $ip_hash, 0, 40 ), $limit );
	}

	/**
	 * Site-wide ceiling for new ratings.
	 *
	 * @return bool
	 */
	public static function hit_global() {
		return self::consume( 'ar_rl_global', (int) apply_filters( 'active_review_global_limit', self::GLOBAL_LIMIT ) );
	}

	/**
	 * Fixed-window counter. Το παράθυρο ΔΕΝ ανανεώνεται σε κάθε hit (αλλιώς
	 * ένας επιμένων επιτιθέμενος θα έμενε κλειδωμένος για πάντα, ενώ ένας
	 * χρήστης που ξαναδοκιμάζει θα πλήρωνε το ίδιο).
	 *
	 * @param string $key   Transient key (≤172 chars).
	 * @param int    $limit Max per window.
	 * @return bool
	 */
	public static function consume( $key, $limit ) {
		$now   = time();
		$state = get_transient( $key );
		if ( ! is_array( $state ) || ! isset( $state['n'], $state['reset'] ) || $state['reset'] <= $now ) {
			$state = array(
				'n'     => 0,
				'reset' => $now + self::WINDOW,
			);
		}
		if ( $state['n'] >= $limit ) {
			return false;
		}
		++$state['n'];
		set_transient( $key, $state, max( 1, $state['reset'] - $now ) );
		return true;
	}
}
