<?php
/**
 * Activation, schema (dbDelta), upgrades, deactivation.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Install {

	const DB_OPTION = 'active_review_db_version';

	/** @return string Full table name. */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'active_reviews';
	}

	/**
	 * Activation: schema + default options + cron.
	 *
	 * @return void
	 */
	public static function activate() {
		self::create_table();
		add_option( AR_Settings::OPTION, AR_Settings::defaults(), '', false );
		add_option( AR_Technicians::OPTION, array(), '', false );
		AR_Retention::schedule();
	}

	/**
	 * Runs dbDelta when the stored schema version is older.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( get_option( self::DB_OPTION ) !== AR_DB_VERSION ) {
			self::create_table();
		}
	}

	/**
	 * Schema. Σημείωση: ΔΕΝ υπάρχει στήλη IP. Μόνο ua_hash (HMAC), και το
	 * token_hash που επιτρέπει στον ίδιο browser να συμπληρώσει σχόλιο.
	 *
	 * @return void
	 */
	public static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$charset = $wpdb->get_charset_collate();

		// dbDelta: δύο κενά μετά το PRIMARY KEY, ένα πεδίο ανά γραμμή.
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			rating tinyint(1) unsigned NOT NULL,
			technician_code varchar(32) NOT NULL DEFAULT '',
			comment text NULL,
			name varchar(100) NOT NULL DEFAULT '',
			phone varchar(30) NOT NULL DEFAULT '',
			went_to_google tinyint(1) unsigned NOT NULL DEFAULT 0,
			ua_hash char(64) NOT NULL DEFAULT '',
			token_hash char(64) NOT NULL DEFAULT '',
			feedback_at datetime NULL DEFAULT NULL,
			notified tinyint(1) unsigned NOT NULL DEFAULT 0,
			anonymized tinyint(1) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY technician_code (technician_code),
			KEY rating (rating),
			KEY token_hash (token_hash)
		) {$charset};";

		dbDelta( $sql );
		update_option( self::DB_OPTION, AR_DB_VERSION, true ); // autoload: διαβάζεται σε κάθε request.
	}

	/**
	 * Deactivation: only unschedules cron. Data stays (uninstall.php decides).
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_unschedule_hook( AR_Retention::CRON_HOOK );
		wp_unschedule_hook( AR_Notify::CRON_HOOK ); // single events με args: μόνο το unschedule_hook τα πιάνει όλα.
	}
}
