<?php
/**
 * Public REST endpoints (namespace active-review/v1).
 *
 *   POST /rate      { rating, t?, token?, website, elapsed }
 *   POST /feedback  { token, comment, name?, phone?, website, elapsed }
 *   POST /google    { token }
 *
 * Γιατί REST και όχι admin-ajax με nonce: η σελίδα κριτικής σερβίρεται από
 * το cache του WP Rocket, οπότε ένα nonce στο HTML θα έληγε (12–24 ώρες) και
 * η φόρμα θα «έσπαγε» σιωπηλά. Τα endpoints είναι ανώνυμα by design και
 * προστατεύονται από το AR_Guard. Το token που επιστρέφει το /rate είναι το
 * μόνο «κλειδί» για να προστεθεί σχόλιο στη συγκεκριμένη εγγραφή — δεν
 * μπορεί κανείς να γράψει σε ξένη εγγραφή.
 *
 * Διαβάζουμε ΜΟΝΟ το JSON σώμα (get_json_params), ποτέ query string ή
 * form-data, ώστε να μην υπάρχουν εναλλακτικοί δρόμοι εισόδου.
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AR_Rest {

	const NS = 'active-review/v1';

	const COMMENT_MAX = 1000;
	const NAME_MAX    = 80;
	const PHONE_MAX   = 30;

	/** @return void */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/** @return void */
	public static function routes() {
		$common = array(
			'methods'             => WP_REST_Server::CREATABLE, // Μόνο POST.
			'permission_callback' => '__return_true',           // Ανώνυμο by design· έλεγχοι στο AR_Guard.
		);
		register_rest_route( self::NS, '/rate', $common + array( 'callback' => array( __CLASS__, 'rate' ) ) );
		register_rest_route( self::NS, '/feedback', $common + array( 'callback' => array( __CLASS__, 'feedback' ) ) );
		register_rest_route( self::NS, '/google', $common + array( 'callback' => array( __CLASS__, 'google' ) ) );
	}

	/* ------------------------------------------------------------------ */
	/* Helpers                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * @param array $data   Body.
	 * @param int   $status HTTP status.
	 * @return WP_REST_Response
	 */
	private static function respond( array $data, $status = 200 ) {
		$response = new WP_REST_Response( $data, $status );
		$response->header( 'Cache-Control', 'no-store, private' );
		$response->header( 'X-Robots-Tag', 'noindex' );
		return $response;
	}

	/**
	 * @param string $code    Machine code.
	 * @param string $message Human message (translated).
	 * @param int    $status  HTTP status.
	 * @return WP_Error
	 */
	private static function error( $code, $message, $status ) {
		return new WP_Error( $code, $message, array( 'status' => $status ) );
	}

	/** @return WP_Error */
	private static function too_many() {
		return self::error( 'ar_rate_limited', __( 'Too many attempts. Please try again later.', 'active-review' ), 429 );
	}

	/**
	 * Transport checks + JSON params. Returns params array or WP_Error.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	private static function params( WP_REST_Request $request ) {
		$ok = AR_Guard::check_transport( $request );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			return self::error( 'ar_bad_json', __( 'Invalid request.', 'active-review' ), 400 );
		}
		return $params;
	}

	/**
	 * Strict star value: JSON integer 1–5 only (no "5", no 5.0, no true).
	 *
	 * @param mixed $value Raw.
	 * @return int 0 when invalid.
	 */
	public static function clean_rating( $value ) {
		return ( is_int( $value ) && $value >= 1 && $value <= 5 ) ? $value : 0;
	}

	/**
	 * Single-line text: sanitized, control chars removed, length-checked.
	 *
	 * @param mixed $value Raw.
	 * @param int   $max   Max chars.
	 * @return string|null Null when invalid type or too long.
	 */
	public static function clean_line( $value, $max ) {
		if ( null === $value ) {
			return '';
		}
		if ( ! is_string( $value ) || strlen( $value ) > $max * 4 ) {
			return null;
		}
		$value = trim( sanitize_text_field( $value ) );
		return mb_strlen( $value ) > $max ? null : $value;
	}

	/**
	 * Multi-line comment: tags stripped, control chars removed, length-checked.
	 *
	 * @param mixed $value Raw.
	 * @return string|null
	 */
	public static function clean_comment( $value ) {
		if ( ! is_string( $value ) || strlen( $value ) > self::COMMENT_MAX * 4 ) {
			return null;
		}
		$value = sanitize_textarea_field( $value );
		$value = (string) preg_replace( '/[\x00-\x09\x0B-\x1F\x7F]/u', '', $value );
		$value = (string) preg_replace( "/\n{3,}/", "\n\n", trim( $value ) );
		return mb_strlen( $value ) > self::COMMENT_MAX ? null : $value;
	}

	/**
	 * Phone: optional; digits and + ( ) - . space; at least 6 digits.
	 *
	 * @param mixed $value Raw.
	 * @return string|null
	 */
	public static function clean_phone( $value ) {
		$value = self::clean_line( $value, self::PHONE_MAX );
		if ( null === $value || '' === $value ) {
			return $value;
		}
		if ( ! preg_match( '/^\+?[0-9 ().\-]{6,30}$/', $value ) || preg_match_all( '/\d/', $value ) < 6 ) {
			return null;
		}
		return $value;
	}

	/**
	 * What the browser may show after a rating. Η απόφαση παίρνεται στον
	 * server (όχι στο cached HTML), ώστε η αλλαγή ρύθμισης να ισχύει αμέσως.
	 *
	 * @param int $rating 1–5.
	 * @return array
	 */
	private static function outcome( $rating ) {
		$google = AR_Settings::google_review_url();
		$show   = '' !== $google && ( $rating >= 4 || (int) AR_Settings::get( 'show_google_link_on_low_rating' ) );
		return array(
			'rating'     => $rating,
			'google_url' => $show ? $google : '',
		);
	}

	/* ------------------------------------------------------------------ */
	/* Endpoints                                                           */
	/* ------------------------------------------------------------------ */

	/**
	 * POST /rate — new rating, or change of the rating behind a fresh token.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rate( WP_REST_Request $request ) {
		$params = self::params( $request );
		if ( is_wp_error( $params ) ) {
			return $params;
		}

		$rating = self::clean_rating( $params['rating'] ?? null );
		if ( ! $rating ) {
			return self::error( 'ar_bad_rating', __( 'Invalid rating.', 'active-review' ), 400 );
		}

		// Bot: ίδια μορφή απάντησης, τίποτα δεν αποθηκεύεται.
		if ( AR_Guard::is_bot( $params ) ) {
			return self::respond( array( 'token' => AR_Repository::new_token() ) + self::outcome( $rating ) );
		}

		$ip_hash = AR_Guard::ip_hash( AR_Guard::client_ip() );

		// Αλλαγή βαθμολογίας (ο πελάτης πάτησε κατά λάθος άλλο αστέρι).
		$token = $params['token'] ?? '';
		if ( is_string( $token ) && '' !== $token ) {
			$row = AR_Repository::find_by_token( $token );
			if ( $row && null === $row->feedback_at ) {
				if ( ! AR_Guard::hit( 'change', $ip_hash ) ) {
					return self::too_many();
				}
				AR_Repository::update_rating( (int) $row->id, $rating );
				if ( $rating < 5 && ! (int) $row->notified ) {
					AR_Notify::schedule( (int) $row->id );
				}
				return self::respond( array( 'token' => $token ) + self::outcome( $rating ) );
			}
			// Ληγμένο/άγνωστο token → συνεχίζουμε ως νέα βαθμολογία.
		}

		if ( ! AR_Guard::hit( 'rate', $ip_hash ) || ! AR_Guard::hit_global() ) {
			return self::too_many();
		}

		$technician = AR_Technicians::resolve( $params['t'] ?? '' );
		$new_token  = AR_Repository::new_token();
		$id         = AR_Repository::insert( $rating, $technician, AR_Guard::ua_hash(), AR_Repository::hash_token( $new_token ) );

		if ( ! $id ) {
			return self::error( 'ar_db', __( 'Something went wrong. Please try again.', 'active-review' ), 500 );
		}
		if ( $rating < 5 ) {
			AR_Notify::schedule( $id );
		}

		return self::respond( array( 'token' => $new_token ) + self::outcome( $rating ), 201 );
	}

	/**
	 * POST /feedback — comment for a 1–4 rating, once per token.
	 * Σχόλιο υποχρεωτικό στα 1–3· στα 4 προαιρετικό, αλλά κάτι πρέπει να σταλεί.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function feedback( WP_REST_Request $request ) {
		$params = self::params( $request );
		if ( is_wp_error( $params ) ) {
			return $params;
		}
		if ( AR_Guard::is_bot( $params ) ) {
			return self::respond( array( 'ok' => true ) );
		}

		$comment = self::clean_comment( $params['comment'] ?? '' );
		$name    = self::clean_line( $params['name'] ?? '', self::NAME_MAX );
		$phone   = self::clean_phone( $params['phone'] ?? '' );

		if ( null === $comment ) {
			return self::error( 'ar_bad_comment', sprintf( /* translators: %d: max characters */ __( 'Please write a comment (up to %d characters).', 'active-review' ), self::COMMENT_MAX ), 400 );
		}
		if ( null === $name ) {
			return self::error( 'ar_bad_name', __( 'The name is too long.', 'active-review' ), 400 );
		}
		if ( null === $phone ) {
			return self::error( 'ar_bad_phone', __( 'Please enter a valid phone number, or leave it empty.', 'active-review' ), 400 );
		}

		$ip_hash = AR_Guard::ip_hash( AR_Guard::client_ip() );
		if ( ! AR_Guard::hit( 'feedback', $ip_hash ) ) {
			return self::too_many();
		}

		$row = AR_Repository::find_by_token( $params['token'] ?? '' );
		if ( ! $row || (int) $row->rating >= 5 ) {
			return self::error( 'ar_expired', __( 'This review session has expired. Please reload the page.', 'active-review' ), 410 );
		}
		$optional = 4 === (int) $row->rating;
		if ( '' === $comment && ( ! $optional || ( '' === $name && '' === $phone ) ) ) {
			return self::error( 'ar_bad_comment', sprintf( /* translators: %d: max characters */ __( 'Please write a comment (up to %d characters).', 'active-review' ), self::COMMENT_MAX ), 400 );
		}
		if ( ! AR_Repository::save_feedback( (int) $row->id, $comment, $name, $phone ) ) {
			return self::error( 'ar_duplicate', __( 'Your comment has already been sent. Thank you!', 'active-review' ), 409 );
		}

		AR_Notify::run( (int) $row->id );

		return self::respond( array( 'ok' => true ) );
	}

	/**
	 * POST /google — records the click before the browser leaves for Google.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function google( WP_REST_Request $request ) {
		$params = self::params( $request );
		if ( is_wp_error( $params ) ) {
			return $params;
		}
		if ( ! AR_Guard::hit( 'google', AR_Guard::ip_hash( AR_Guard::client_ip() ) ) ) {
			return self::too_many();
		}
		$row = AR_Repository::find_by_token( $params['token'] ?? '' );
		if ( $row ) {
			$allowed = 5 === (int) $row->rating || (int) AR_Settings::get( 'show_google_link_on_low_rating' );
			if ( $allowed ) {
				AR_Repository::mark_google( (int) $row->id );
			}
		}
		// Πάντα ίδια απάντηση: δεν αποκαλύπτουμε αν ένα token υπάρχει.
		return self::respond( array( 'ok' => true ) );
	}
}
