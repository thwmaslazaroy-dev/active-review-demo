/**
 * Active Review — public widget. Vanilla JS, no dependencies.
 *
 * Ασφάλεια: κείμενα από τον server μπαίνουν ΜΟΝΟ με textContent (ποτέ
 * innerHTML) και η πλοήγηση προς Google γίνεται μόνο σε URL που ξεκινά από
 * το αναμενόμενο origin.
 */
(function () {
	'use strict';

	var GOOGLE_PREFIX = 'https://search.google.com/local/writereview?';
	var startedAt = Date.now();

	function init(root) {
		var config;
		try {
			config = JSON.parse(root.getAttribute('data-ar-config') || '{}');
		} catch (e) {
			return;
		}
		var i18n = config.i18n || {};
		var state = { token: '', rating: 0, googleUrl: '', busy: false };

		var params = new URLSearchParams(window.location.search);
		var tech = (params.get('t') || '').slice(0, 32);

		var steps = {};
		root.querySelectorAll('[data-ar-step]').forEach(function (el) {
			steps[el.getAttribute('data-ar-step')] = el;
		});
		var stars = Array.prototype.slice.call(root.querySelectorAll('.ar-star'));
		var form = root.querySelector('[data-ar-form]');
		var formError = root.querySelector('[data-ar-error]');
		var globalError = root.querySelector('[data-ar-global-error]');
		var live = root.querySelector('[data-ar-live]');
		var submitBtn = root.querySelector('[data-ar-submit]');
		var honeypot = root.querySelector('input[name="website"]');
		var comment = form ? form.querySelector('textarea[name="comment"]') : null;
		var counter = root.querySelector('[data-ar-count]');

		/* ---------- helpers ---------- */

		function show(name) {
			Object.keys(steps).forEach(function (key) {
				steps[key].hidden = key !== name;
			});
			var target = steps[name];
			if (name !== 'rate' && target) {
				target.focus({ preventScroll: true });
				target.scrollIntoView({ block: 'start', behavior: 'smooth' });
			}
		}

		function setError(el, msg) {
			if (!el) { return; }
			el.textContent = msg || '';
			el.hidden = !msg;
		}

		function post(path, body, keepalive) {
			body.website = honeypot ? honeypot.value : '';
			body.elapsed = Math.round(Date.now() - startedAt);
			return fetch(config.restUrl + path, {
				method: 'POST',
				credentials: 'omit', // Δεν χρειαζόμαστε cookies — ανώνυμο endpoint.
				keepalive: !!keepalive,
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify(body)
			}).then(function (res) {
				return res.json().catch(function () { return {}; }).then(function (json) {
					if (!res.ok) {
						var err = new Error(typeof json.message === 'string' ? json.message : (i18n.generic || 'Error'));
						err.status = res.status;
						throw err;
					}
					return json;
				});
			}, function () {
				throw new Error(i18n.network || 'Network error');
			});
		}

		function safeGoogle(url) {
			return typeof url === 'string' && url.indexOf(GOOGLE_PREFIX) === 0 ? url : '';
		}

		/* ---------- stars ---------- */

		function paint(upTo) {
			stars.forEach(function (star, idx) {
				star.classList.toggle('is-on', idx < upTo);
			});
		}

		function focusStar(idx) {
			idx = Math.max(0, Math.min(stars.length - 1, idx));
			stars.forEach(function (star, i) { star.tabIndex = i === idx ? 0 : -1; });
			stars[idx].focus();
		}

		function select(value) {
			if (state.busy) { return; }
			state.busy = true;
			setError(globalError, '');
			root.classList.add('is-busy');
			stars.forEach(function (star) {
				star.setAttribute('aria-pressed', String(Number(star.getAttribute('data-value')) === value));
			});
			paint(value);

			post('rate', { rating: value, t: tech, token: state.token })
				.then(function (json) {
					state.token = typeof json.token === 'string' ? json.token : '';
					state.rating = value;
					state.googleUrl = safeGoogle(json.google_url);
					if (live && i18n.selected) {
						live.textContent = i18n.selected.replace('%d', String(value));
					}

					root.querySelectorAll('[data-ar-google]').forEach(function (a) {
						a.href = state.googleUrl || '#';
						a.hidden = !state.googleUrl;
					});
					var lowLink = root.querySelector('[data-ar-google-low]');
					if (lowLink) { lowLink.hidden = !(value < 5 && state.googleUrl); }

					show(value === 5 ? 'high' : 'low');
					if (value < 5 && comment) {
						setTimeout(function () { comment.focus(); }, 350);
					}
				})
				.catch(function (err) {
					paint(state.rating);
					setError(globalError, err.message);
				})
				.then(function () {
					state.busy = false;
					root.classList.remove('is-busy');
				});
		}

		stars.forEach(function (star, idx) {
			var value = idx + 1;
			star.addEventListener('click', function () { select(value); });
			star.addEventListener('mouseenter', function () { paint(value); });
			star.addEventListener('focus', function () { paint(value); });
			star.addEventListener('keydown', function (e) {
				var key = e.key;
				if (key === 'ArrowRight' || key === 'ArrowUp') { e.preventDefault(); focusStar(idx + 1); }
				else if (key === 'ArrowLeft' || key === 'ArrowDown') { e.preventDefault(); focusStar(idx - 1); }
				else if (key === 'Home') { e.preventDefault(); focusStar(0); }
				else if (key === 'End') { e.preventDefault(); focusStar(stars.length - 1); }
			});
		});
		var group = root.querySelector('[data-ar-stars]');
		if (group) {
			group.addEventListener('mouseleave', function () { paint(state.rating); });
			group.addEventListener('focusout', function (e) {
				if (!group.contains(e.relatedTarget)) { paint(state.rating); }
			});
		}

		/* ---------- change rating ---------- */

		root.querySelectorAll('[data-ar-change]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				show('rate');
				focusStar(Math.max(0, state.rating - 1));
			});
		});

		/* ---------- Google click: log, then leave ---------- */

		root.querySelectorAll('[data-ar-google]').forEach(function (a) {
			a.addEventListener('click', function (e) {
				var url = safeGoogle(state.googleUrl);
				if (!url) { e.preventDefault(); return; }
				e.preventDefault();
				var go = function () { window.location.href = url; };
				// keepalive: το αίτημα ολοκληρώνεται ακόμη κι αν η σελίδα φύγει.
				var timer = setTimeout(go, 700);
				post('google', { token: state.token }, true).catch(function () {}).then(function () {
					clearTimeout(timer);
					go();
				});
			});
		});

		/* ---------- feedback form ---------- */

		function updateCount() {
			if (!counter || !comment) { return; }
			var max = Number(counter.getAttribute('data-max')) || 1000;
			var left = max - comment.value.length;
			counter.textContent = (i18n.charsLeft || '%s').replace('%s', String(left));
		}
		if (comment) {
			comment.addEventListener('input', updateCount);
			updateCount();
		}

		if (form) {
			form.addEventListener('submit', function (e) {
				e.preventDefault();
				if (state.busy) { return; }
				var text = comment ? comment.value.trim() : '';
				if (!text) {
					setError(formError, i18n.required);
					if (comment) { comment.setAttribute('aria-invalid', 'true'); comment.focus(); }
					return;
				}
				if (comment) { comment.removeAttribute('aria-invalid'); }
				setError(formError, '');
				state.busy = true;
				submitBtn.disabled = true;
				submitBtn.textContent = i18n.sending || '…';

				post('feedback', {
					token: state.token,
					comment: text,
					name: form.elements.name.value.trim(),
					phone: form.elements.phone.value.trim()
				})
					.then(function () {
						show('done');
					})
					.catch(function (err) {
						if (err.status === 409) { show('done'); return; }
						setError(formError, err.message);
					})
					.then(function () {
						state.busy = false;
						submitBtn.disabled = false;
						submitBtn.textContent = i18n.send || 'Send';
					});
			});
		}
	}

	function boot() {
		document.querySelectorAll('[data-ar-root]').forEach(init);
	}
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
