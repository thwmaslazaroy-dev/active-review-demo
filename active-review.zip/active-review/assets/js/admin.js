/**
 * Active Review — settings page: logo picker (WordPress media library).
 */
(function () {
	'use strict';
	var pick = document.getElementById('ar-logo-pick');
	var clear = document.getElementById('ar-logo-clear');
	var input = document.getElementById('ar-logo_id');
	var preview = document.getElementById('ar-logo-preview');
	if (!pick || !input || !window.wp || !wp.media) { return; }

	var frame;
	pick.addEventListener('click', function () {
		if (!frame) {
			frame = wp.media({ library: { type: 'image' }, multiple: false });
			frame.on('select', function () {
				var att = frame.state().get('selection').first().toJSON();
				var size = (att.sizes && att.sizes.medium) || att;
				input.value = String(parseInt(att.id, 10) || 0);
				preview.textContent = '';
				var img = document.createElement('img');
				img.src = size.url;
				img.alt = '';
				preview.appendChild(img);
				clear.hidden = false;
			});
		}
		frame.open();
	});
	clear.addEventListener('click', function () {
		input.value = '0';
		preview.textContent = '';
		clear.hidden = true;
	});
})();
