/**
 * Active Review — QR generator (fully local, qrcode-generator MIT, no CDN).
 *
 * SVG: διανυσματικό, ένα path, με λευκό quiet zone 4 modules (απαίτηση του
 * προτύπου για αξιόπιστο σκανάρισμα σε εκτύπωση).
 * PNG: 2048×2048 px, χωρίς εξομάλυνση (καθαρές άκρες).
 */
(function () {
	'use strict';
	var QUIET = 4;
	var PNG_SIZE = 2048;
	var SVG_NS = 'http://www.w3.org/2000/svg';

	function matrix(url) {
		var qr = qrcode(0, 'M');
		qr.addData(url, 'Byte');
		qr.make();
		var n = qr.getModuleCount();
		var cells = [];
		for (var r = 0; r < n; r++) {
			for (var c = 0; c < n; c++) {
				if (qr.isDark(r, c)) { cells.push([c, r]); }
			}
		}
		return { n: n, cells: cells };
	}

	function buildSvg(m) {
		var size = m.n + QUIET * 2;
		var svg = document.createElementNS(SVG_NS, 'svg');
		svg.setAttribute('xmlns', SVG_NS);
		svg.setAttribute('viewBox', '0 0 ' + size + ' ' + size);
		svg.setAttribute('width', '1024');
		svg.setAttribute('height', '1024');
		svg.setAttribute('shape-rendering', 'crispEdges');
		var bg = document.createElementNS(SVG_NS, 'rect');
		bg.setAttribute('width', String(size));
		bg.setAttribute('height', String(size));
		bg.setAttribute('fill', '#ffffff');
		svg.appendChild(bg);
		var d = m.cells.map(function (p) {
			return 'M' + (p[0] + QUIET) + ' ' + (p[1] + QUIET) + 'h1v1h-1z';
		}).join('');
		var path = document.createElementNS(SVG_NS, 'path');
		path.setAttribute('d', d);
		path.setAttribute('fill', '#000000');
		svg.appendChild(path);
		return svg;
	}

	function buildCanvas(m) {
		var size = m.n + QUIET * 2;
		var scale = Math.floor(PNG_SIZE / size);
		var offset = Math.floor((PNG_SIZE - scale * size) / 2);
		var canvas = document.createElement('canvas');
		canvas.width = PNG_SIZE;
		canvas.height = PNG_SIZE;
		var ctx = canvas.getContext('2d');
		ctx.imageSmoothingEnabled = false;
		ctx.fillStyle = '#ffffff';
		ctx.fillRect(0, 0, PNG_SIZE, PNG_SIZE);
		ctx.fillStyle = '#000000';
		m.cells.forEach(function (p) {
			ctx.fillRect(offset + (p[0] + QUIET) * scale, offset + (p[1] + QUIET) * scale, scale, scale);
		});
		return canvas;
	}

	function download(blob, filename) {
		var url = URL.createObjectURL(blob);
		var a = document.createElement('a');
		a.href = url;
		a.download = filename;
		document.body.appendChild(a);
		a.click();
		a.remove();
		setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
	}

	document.querySelectorAll('[data-ar-qr]').forEach(function (box) {
		var url = box.getAttribute('data-url') || '';
		var file = box.getAttribute('data-file') || 'active-review-qr';
		var m;
		try {
			m = matrix(url);
		} catch (e) {
			box.querySelector('[data-ar-qr-target]').textContent = 'QR error';
			return;
		}
		var preview = buildSvg(m);
		preview.setAttribute('width', '220');
		preview.setAttribute('height', '220');
		box.querySelector('[data-ar-qr-target]').appendChild(preview);

		box.querySelector('[data-ar-qr-svg]').addEventListener('click', function () {
			var xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(buildSvg(m));
			download(new Blob([xml], { type: 'image/svg+xml' }), file + '.svg');
		});
		box.querySelector('[data-ar-qr-png]').addEventListener('click', function () {
			buildCanvas(m).toBlob(function (blob) {
				if (blob) { download(blob, file + '.png'); }
			}, 'image/png');
		});
	});
})();
