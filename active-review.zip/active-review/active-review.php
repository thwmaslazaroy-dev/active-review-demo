<?php
/**
 * Plugin Name:       Active Review
 * Plugin URI:        https://workelion.com
 * Description:       Σύστημα κριτικών πελατών για την Active Security: βαθμολογία με αστέρια, εσωτερική φόρμα βελτίωσης, σύνδεσμος κριτικής Google, στατιστικά ανά τεχνικό και QR για εκτύπωση.
 * Version:           1.1.0
 * Requires at least: 6.5
 * Requires PHP:      8.1
 * Author:            Workelion — Thomas Lazarou
 * Author URI:        https://workelion.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       active-review
 * Domain Path:       /languages
 *
 * @package ActiveReview
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AR_VERSION', '1.1.0' );
define( 'AR_DB_VERSION', '1' );
define( 'AR_FILE', __FILE__ );
define( 'AR_PATH', plugin_dir_path( __FILE__ ) );
define( 'AR_URL', plugin_dir_url( __FILE__ ) );
define( 'AR_BASENAME', plugin_basename( __FILE__ ) );

require_once AR_PATH . 'includes/class-ar-settings.php';
require_once AR_PATH . 'includes/class-ar-install.php';
require_once AR_PATH . 'includes/class-ar-technicians.php';
require_once AR_PATH . 'includes/class-ar-repository.php';
require_once AR_PATH . 'includes/class-ar-guard.php';
require_once AR_PATH . 'includes/class-ar-notify.php';
require_once AR_PATH . 'includes/class-ar-rest.php';
require_once AR_PATH . 'includes/class-ar-shortcode.php';
require_once AR_PATH . 'includes/class-ar-retention.php';

if ( is_admin() ) {
	require_once AR_PATH . 'includes/class-ar-stats.php';
	require_once AR_PATH . 'includes/class-ar-export.php';
	require_once AR_PATH . 'includes/class-ar-admin.php';
}

register_activation_hook( __FILE__, array( 'AR_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'AR_Install', 'deactivate' ) );

add_action( 'plugins_loaded', 'active_review_bootstrap' );

/**
 * Wires every component. One place, one order.
 *
 * @return void
 */
function active_review_bootstrap() {
	// Μεταφράσεις στο init (όχι νωρίτερα): από το WP 6.7 η φόρτωση πριν το
	// init βγάζει notice «translation loading triggered too early».
	add_action(
		'init',
		static function () {
			load_plugin_textdomain( 'active-review', false, dirname( AR_BASENAME ) . '/languages' );
		},
		1
	);

	AR_Install::maybe_upgrade();
	AR_Rest::init();
	AR_Shortcode::init();
	AR_Notify::init();
	AR_Retention::init();

	if ( is_admin() ) {
		AR_Admin::init();
		AR_Export::init();
	}
}
