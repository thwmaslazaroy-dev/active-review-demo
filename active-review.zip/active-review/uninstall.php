<?php
/**
 * Uninstall: deletes data ONLY if "Delete all data on uninstall" is checked.
 *
 * Προεπιλογή: τα δεδομένα μένουν, ώστε μια κατά λάθος διαγραφή του plugin να
 * μη χάσει ιστορικό κριτικών. Τα cron events καθαρίζονται πάντα.
 *
 * @package ActiveReview
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

wp_unschedule_hook( 'active_review_retention' );
wp_unschedule_hook( 'active_review_notify' );

$active_review_settings = get_option( 'active_review_settings', array() );

if ( is_array( $active_review_settings ) && ! empty( $active_review_settings['delete_on_uninstall'] ) ) {
	global $wpdb;
	$active_review_table = $wpdb->prefix . 'active_reviews';
	$wpdb->query( "DROP TABLE IF EXISTS `{$active_review_table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.SchemaChange -- internal name.

	delete_option( 'active_review_settings' );
	delete_option( 'active_review_technicians' );
	delete_option( 'active_review_db_version' );

	// Transients του rate limit (λήγουν μόνα τους σε 1 ώρα· τα σβήνουμε για καθαρότητα).
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_ar\_rl\_%' OR option_name LIKE '\_transient\_timeout\_ar\_rl\_%' OR option_name LIKE '\_transient\_ar\_mail\_cap%' OR option_name LIKE '\_transient\_timeout\_ar\_mail\_cap%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}
